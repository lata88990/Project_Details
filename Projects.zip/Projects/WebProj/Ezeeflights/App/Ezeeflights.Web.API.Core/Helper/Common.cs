﻿using Fastlane.Platform.Air.Models.Web;
using Ezeeflights.Web.API.Core.Models;

namespace Ezeeflights.Web.API.Core.Helper
{
    public class Common
    {
        public static string ApiKey = "1727fe3d53d40622240735b0eddad73b";

        //public static void FlightTrack(IConfiguration configuration, FlightsSearch flightSearch)
        //{
        //    if (flightSearch != null)
        //    {

        //        // save search data in database
        //        string sqlquery = $"INSERT INTO FlightTrack(FromAirport,ToAirport,DepDate,RetDate,Adult,Child,Infant,FlightWay,FlightClass,IsDirect,IsFlexi,SiteCode,SourceMedia,Timestamp) VALUES('" + flightSearch.From.Code.Replace("'", "''") + "','" + flightSearch.To.Code.Replace("'", "''") + "','" + flightSearch.DepDate + "','" + flightSearch.RetDate + "'," + flightSearch.Adult + "," + flightSearch.Child + "," + flightSearch.Infant + ",'" + flightSearch.FlightWay + "','" + flightSearch.FlightClass.ToString().Replace("'", "''") + "'," + Convert.ToInt32(flightSearch.IsDirect) + "," + Convert.ToInt32(flightSearch.IsFlexi) + ",'" + flightSearch.SiteCode + "','" + flightSearch.SourceMedia + "','" + DateTime.Now + "')";


        //        string sqlDataSource = configuration.GetConnectionString("DefaultConnection");
        //        using (SqlConnection myCon = new SqlConnection(sqlDataSource))
        //        {
        //            myCon.Open();
        //            SqlDataAdapter adapter = new SqlDataAdapter();
        //            adapter.SelectCommand = new SqlCommand(sqlquery, myCon);
        //            int t = adapter.SelectCommand.ExecuteNonQuery();
        //            myCon.Close();
        //        }
        //    }
        //}
        //public static List<Airline> GetAllAirline(IConfiguration configuration)
        //{
        //    List<Airline> airline = new List<Airline>();

        //    string sqlquery = $"SELECT * FROM Airline ORDER BY Name";

        //    string sqlDataSource = configuration.GetConnectionString("DefaultConnection");
        //    using (SqlConnection myCon = new SqlConnection(sqlDataSource))
        //    {
        //        myCon.Open();
        //        SqlDataAdapter adapter = new SqlDataAdapter();
        //        adapter.SelectCommand = new SqlCommand(sqlquery, myCon);
        //        airline = adapter.SelectCommand.ExecuteNonQuery();
        //        myCon.Close();
        //    }


        //    return airline;
        //}
        //public static Location GetLocation(string Code)
        //{
        //    Location location = new Location();

        //    DataSet ds = SqlHelper.ExecuteDataset("SELECT * FROM City WHERE TravellandaCityId='" + Code + "'", null);

        //    if (ds != null && ds.Tables[0].Rows.Count > 0)
        //    {
        //        DataRow dr = ds.Tables[0].Rows[0];

        //        location.CityId = dr["CityId"].ToString();
        //        location.TravellandaCityId = dr["TravellandaCityId"].ToString();
        //        location.CityName = dr["CityName"].ToString();
        //        location.StateCode = dr["StateCode"].ToString();
        //        location.StateName = dr["StateCode"].ToString();
        //        location.CountryCode = dr["CountryCode"].ToString();
        //        location.CountryName = dr["CountryName"].ToString();
        //        location.Latitude = "";
        //        location.Longtitude = "";
        //    }
        //    else
        //    {
        //        location.CityId = Code;
        //        location.CityName = Code;
        //        location.StateName = Code;
        //        location.CountryCode = Code;
        //        location.CountryName = Code;
        //        location.Latitude = "";
        //        location.Longtitude = "";
        //    }

        //    return location;
        //}

        public static FlightSearchRQ GetFlightSearch(FlightSearchModel flightSearchModel)
        {
            FlightSearchRQ flightSearch = new()
            {
                SearchId = Guid.NewGuid().ToString(),
                FlightWay = flightSearchModel.RDate.HasValue ? FlightWay.RoundTrip : FlightWay.OneWay,
                From = flightSearchModel.Org,
                To = flightSearchModel.Des,
                DepDate = flightSearchModel.DDate
            };
            flightSearch.Adult = flightSearchModel.Adt;
            flightSearch.Child = flightSearchModel.Chld;
            flightSearch.Infant = flightSearchModel.Inf;
            flightSearch.FlightClass = ConvertCabinClass(flightSearchModel.Cabin);
            flightSearch.IsDirect = flightSearchModel.DirectFlightsOnly;
            flightSearch.Currency = "USD";
            flightSearch.SiteCode = "Web";
            flightSearch.SourceMedia = flightSearchModel.Ref ?? flightSearchModel.utm_source ?? "Web";
            flightSearch.IsDeepLink = true;
            flightSearch.ApiKey = Common.ApiKey;
            flightSearch.TranId = Guid.NewGuid().ToString();
            flightSearch.Airline = new Fastlane.Platform.Air.Models.Web.Airline() { Code = "", Name = "" };
            flightSearch.PreferedAirlines = new List<string>();
            if (flightSearchModel.RDate.HasValue)
            {
                flightSearch.RetDate = flightSearchModel.RDate.Value;
            }
            return flightSearch;
        }

        private static FlightClass ConvertCabinClass(string cabinClassRQ)
        {
            FlightClass flightClass = FlightClass.Economy;
            switch (cabinClassRQ)
            {
                case "PremiumEconomy":
                    flightClass = FlightClass.EconomyPremium;
                    break;

                case "Business":
                    flightClass = FlightClass.Business;
                    break;

                case "First":
                    flightClass = FlightClass.First;
                    break;

                case "Economy":
                default:
                    flightClass = FlightClass.Economy;
                    break;
            }
            return flightClass;
        }

        //public static string SendEmail(string ToEmail, string EmailSubject, string EMailBody, string EmailCC = "", string EmailBCC = "", bool isBodyHtml = true)
        //{
        //    try
        //    {
        //        WebMail.SmtpServer = "auth.smtp.1and1.co.uk";
        //        WebMail.SmtpServer = "smtp.gmail.com";
        //        WebMail.SmtpPort = 587;
        //        WebMail.SmtpUseDefaultCredentials = true;


        //        WebMail.UserName = "booking@travolie.com";
        //        WebMail.Password = "Passi@123456789";
        //        WebMail.From = "Travolie <booking@travolie.com>";
        //        WebMail.EnableSsl = true;
        //        //WebMail.UserName = "booking@flightoffice.co.uk";
        //        //WebMail.Password = "Passi@123456789";
        //        //WebMail.From = "Travolie <booking@flightoffice.co.uk>";

        //        WebMail.Send(to: ToEmail, subject: EmailSubject, body: EMailBody, cc: EmailCC, bcc: EmailBCC, isBodyHtml: true);
        //        return "success";
        //    }
        //    catch (Exception e)
        //    {
        //        return e.ToString();
        //    }
        //}
        public static string UcFirst(string input)
        {
            if (String.IsNullOrEmpty(input))
                return "";
            return input.First().ToString().ToUpper() + String.Join("", input.Skip(1));
        }
        public static int GetTime(DateTime d2, DateTime d1)
        {
            TimeSpan span = d2.Subtract(d1);
            return (int)span.TotalMinutes;
        }
    }

}
