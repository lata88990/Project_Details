﻿using Ezeeflights.Web.API.Core.Models;

namespace Ezeeflights.Web.API.Core.Services
{
    public interface IMailService
    {
        Task SendEmailAsync(MailData mailData);
    }
}
