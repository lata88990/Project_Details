﻿using Ezeeflights.Web.API.Core.Models;
using Ezeeflights.Web.API.Core.Models;
using Fastlane.Platform.Air.Models.Web;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Json;
using System.Text;

namespace Ezeeflights.Web.API.Core.Services
{
    public class FlightSearchClient
    {
        private readonly HttpClient httpClient;
        private readonly IConfiguration configuration;

        public FlightSearchClient(HttpClient httpClient, IConfiguration configuration)
        {
            this.httpClient = httpClient;
            this.configuration = configuration;
        }

        public async Task<FlightSearchRS?> Search(FlightSearchRQ flightSearch)
        {
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("X-Api-Key", TryGetApiKeyValue(flightSearch.SourceMedia));
            var response = await httpClient.PostAsJsonAsync("api/Flights/Search", flightSearch);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<FlightSearchRS>();
            }
            return null;
        }

        public async Task<FlightDetail?> GetSelectedFlightDetails(FlightSearchRQ flightSearch)
        {
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("X-Api-Key", TryGetApiKeyValue(flightSearch.SourceMedia));
            var response = await httpClient.PostAsJsonAsync("api/Flights/Select", flightSearch);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<FlightDetail>();
            }
            return null;
        }


        public async Task<string?> GetGoogleFlights(string itinerary)
        {
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("X-Api-Key", TryGetApiKeyValue("GOOGLE"));
            var response = await httpClient.PostAsync("api/GoogleFlights", new StringContent(System.Text.Json.JsonSerializer.Serialize(itinerary),null, "application/json"));
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsStringAsync();
            }
            return null;
        }

        private string TryGetApiKeyValue(string key)
        {
            return configuration[$"ApiKey:{key.ToUpperInvariant()}"];
        }
    }
}
