﻿using Ezeeflights.Web.API.Core.Models;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;

namespace Ezeeflights.Web.API.Core.Services
{
    public class MailService : IMailService
    {
        private readonly MailSettings _mailSettings;
        public MailService(IOptions<MailSettings> mailSettings)
        {
            _mailSettings = mailSettings.Value;
        }
        public async Task SendEmailAsync(MailData mailRequest)
        {
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress(_mailSettings.Mail);
            foreach (var toEmail in mailRequest.ToEmail)
            {
                message.To.Add(new MailAddress(toEmail));
            }
            if (!string.IsNullOrEmpty(mailRequest.ToBccEmail))
            {
                message.Bcc.Add(new MailAddress(mailRequest.ToBccEmail));
            }
            message.Subject = mailRequest.Subject;
            message.IsBodyHtml = true; //to make message body as html  
            message.Body = mailRequest.Body;
            smtp.Port = _mailSettings.Port;
            smtp.Host = _mailSettings.Host;

            //smtp.UseDefaultCredentials = true;
            smtp.Credentials = new NetworkCredential(_mailSettings.Mail, _mailSettings.Password);
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            //smtp.EnableSsl = true;
            //  smtp.Send(message);


            try
            {
                await smtp.SendMailAsync(message);
            }
            catch (Exception ex)
            {

            }

        }
    }
}
