﻿using Ezeeflights.Web.API.Core.Models;
using Fastlane.Platform.Air.Models.Web;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Ezeeflights.Web.API.Core.Repo
{
    public class FileStorageRepository : IStorageRepository
    {
        private const string File_Base_Path = @"App_Data/Bookings";
        private readonly IConfiguration configuration;
        private readonly ILogger<FileStorageRepository> logger;
        public FileStorageRepository(IConfiguration configuration, ILogger<FileStorageRepository> logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }
        public async ValueTask<FlightsBookingRQ?> Get(string bookingId)
        {
            try
            {
                if (Directory.Exists(File_Base_Path))
                {
                    using var resultFile = new FileStream(Path.Combine(File_Base_Path, bookingId + ".json"), FileMode.Open, FileAccess.Read);
                    return await JsonSerializer.DeserializeAsync<FlightsBookingRQ>(resultFile);
                }

            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception Occured while reading file.");
            }
            return null;

        }

        public async Task<bool> TrySaveResult(FlightsBookingRQ flightsBookingRQ)
        {

            try
            {
                if (Directory.Exists(File_Base_Path))
                {
                    var filePath = Path.Combine(File_Base_Path, flightsBookingRQ.BookingId + ".json");
                    using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                    await JsonSerializer.SerializeAsync(fileStream, flightsBookingRQ);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception Occured while saving file.");
                return false;
            }
            return true;
        }
    }
}
