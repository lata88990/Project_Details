﻿using Fastlane.Platform.Air.Models.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ezeeflights.Web.API.Core.Repo
{
    public interface IStorageRepository
    {
        Task<bool> TrySaveResult(FlightsBookingRQ flightsBookingRQ);

        ValueTask<FlightsBookingRQ?> Get(string bookingId);

    }
}
