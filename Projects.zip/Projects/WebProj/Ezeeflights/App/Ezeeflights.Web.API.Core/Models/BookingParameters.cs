﻿using System.ComponentModel.DataAnnotations;

namespace Ezeeflights.Web.API.Core.Models
{
    public class FlightItinerarySearchModel : FlightSearchModel
    {
        [Required]
        public string SearchId { get; set; }
        [Required]
        public string TranId { get; set; }
    }
}
