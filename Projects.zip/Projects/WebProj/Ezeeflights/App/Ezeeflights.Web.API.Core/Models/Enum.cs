﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ezeeflights.Web.API.Core.Models
{

    public enum PassengerType : int
    {
        None = 0,
        Adult = 1,
        Child = 2,
        Infant = 3
    }

    public enum Gender : int
    {
        None = 0,
        Male = 1,
        Female = 2,
    }

}