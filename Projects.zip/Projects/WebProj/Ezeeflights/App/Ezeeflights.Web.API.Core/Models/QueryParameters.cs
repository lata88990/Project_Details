﻿using System.ComponentModel.DataAnnotations;
using Ezeeflights.Web.API.Core.Models;

namespace Ezeeflights.Web.API.Core.Models
{
    //https://www.ezeeflights.com/flights/result?org=JFK&des=ATL&dDate=2023-3-10&rDate=2023-3-24&adt=1&chld=0&inf=0&cabin=Economy&utm_source=CheapFlights&utm_medium=cpc&utm_campaign=flight-search-deeplink
    public class FlightSearchModel
    {
        [Required]
        public string Org { get; set; }
        [Required]
        public string Des { get; set; }
        public DateTime DDate { get; set; }
        public DateTime? RDate { get; set; }
        public int Adt { get; set; }
        public int Chld { get; set; }

        public int Inf { get; set; }

        public string Ref { get; set; }

        public string TCode { get; set; }

        public string Cabin
        {
            get; set;
        }

        public bool DirectFlightsOnly
        { get; set; }

        public string utm_source { get; set; }
        public string utm_medium { get; set; }
        public string utm_campaign { get; set; }

    }
}
