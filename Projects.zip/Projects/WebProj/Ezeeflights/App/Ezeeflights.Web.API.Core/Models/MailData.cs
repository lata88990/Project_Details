﻿using Microsoft.AspNetCore.Http;

namespace Ezeeflights.Web.API.Core.Models
{
    public class MailData
    {
        // Receiver
        public string[] ToEmail { get; set; }
        public string[] ToCcEmail { get; set; }
        public string ToBccEmail { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<IFormFile> Attachments { get; set; }
    }
}
