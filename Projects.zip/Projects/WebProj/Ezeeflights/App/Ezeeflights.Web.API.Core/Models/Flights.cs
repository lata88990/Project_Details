﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ezeeflights.Web.API.Core.Models;
using Fastlane.Platform.Air.Models.Web;

namespace Ezeeflights.Web.API.Core.Models
{

    public partial class FareMarkUp
    {
        public double OutboundMarkUp { get; set; }
        public double InboundMarkUp { get; set; }
        public double OutboundMarkUpC { get; set; }
        public double InboundMarkUpC { get; set; }
        public double WorldspanFare { get; set; }
        public double WorldspanTax { get; set; }
        public double WorldspanFareC { get; set; }
        public double WorldspanTaxC { get; set; }



        public string OutBoundClass { get; set; }
        public string InBoundClass { get; set; }
    }


    public class FlightsFare
    {
        public double AdultFare { get; set; }
        public double AdultDiscountValue { get; set; }
        public double ChildFare { get; set; }
        public double InfantFare { get; set; }
        public double AdultTax { get; set; }
        public double AdultTaxDiscountValue { get; set; }
        public double ChildTax { get; set; }
        public double InfantTax { get; set; }
        public double AvlFr { get; set; }
        public double AdultMarkup { get; set; }
        public double ChildMarkup { get; set; }
        public double InfantMarkup { get; set; }
        public string MarkupType { get; set; }
        public int Adult { get; set; }
        public int Child { get; set; }
        public int Infant { get; set; }
        public double AtolCharge { get; set; }
        public double CardCharge { get; set; }
        public double AvgCost
        {
            set { }
            get
            {
                return (GrandTotal / (Adult + Child + Infant));
            }
        }
        public double GrandTotal
        {
            set { }
            get
            {
                //OLD CODE WITH TAX
                //return (((AdultFare + AdultMarkup + AdultTax) * Adult) + ((ChildFare + ChildMarkup + ChildTax) * Child) + ((InfantFare + InfantMarkup + InfantTax) * Infant));

                return (((AdultFare + AdultMarkup) * Adult) + ((ChildFare + ChildMarkup) * Child) + ((InfantFare + InfantMarkup + InfantTax) * Infant));
            }
        }
    }

    public class BagsPrice
    {
        public string BagsPcs { get; set; }
        public float BagsPcsPrice { get; set; }
    }

    public class Baglimit
    {
        public string hand_width { get; set; }
        public string hand_height { get; set; }
        public string hand_length { get; set; }
        public string hand_weight { get; set; }
        public string hold_width { get; set; }
        public string hold_height { get; set; }
        public string hold_length { get; set; }
        public string hold_weight { get; set; }
        public string hold_dimensions_sum { get; set; }
    }




    public class FilterResult
    {
        public string Airline { get; set; }
        public float Price { get; set; }
        public List<FilterSegment> OutboundFilter { get; set; }
        public List<FilterSegment> InboundFilter { get; set; }
    }
    public class FilterSegment
    {
        public int Stops { get; set; }
        public int PlaneTime { get; set; }
    }

    public class FlightsExtra
    {
        public string FlightId { get; set; }
        public string ExtraType { get; set; }
        public Airline Airline { get; set; }
        public double TotalCost { get; set; }
        public int TotalTime { get; set; }
        public int TotalStop { get; set; }
        public string Provider { get; set; }
    }

    //public class Airport
    //{
    //    public long Id { get; set; }
    //    public string Code { get; set; }
    //    public string Name { get; set; }
    //    public string CityCode { get; set; }
    //    public string CityName { get; set; }
    //    public string StateCode { get; set; }
    //    public string StateName { get; set; }
    //    public string CountryCode { get; set; }
    //    public string CountryName { get; set; }
    //    public string Continent { get; set; }
    //    public string Latitude { get; set; }
    //    public string Longtitude { get; set; }
    //}

    //public class Airline
    //{
    //    public long Id { get; set; }
    //    public string Code { get; set; }
    //    public string Name { get; set; }
    //}


    public class Location
    {
        public string CityId { get; set; }
        public string TravellandaCityId { get; set; }
        public string CityName { get; set; }
        public string CityCode { get; set; }
        public string Latitude { get; set; }
        public string Longtitude { get; set; }
        public string StateCode { get; set; }
        public string StateName { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
    }

    public class BookerDetail
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string PhoneNo { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string AlternativeEmail { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string PostCode { get; set; }
    }


    public class BookingTicket
    {
        public string TransactionId { get; set; }
        public string TotalFare { get; set; }
        public string LastTicketingDate { get; set; }
        public bool AllowTicketing { get; set; }
        public List<Passengers> Passengers { get; set; }
        public ContactDetails ContactDetails { get; set; }
        public PaymentDetails PaymentDetails { get; set; }
        public List<PnrRemarks> PnrRemarks { get; set; }
        public GstData GstData { get; set; }
    }

    public class Passengers
    {
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string PaxType { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Nationality { get; set; }
        public string IdentityNumber { get; set; }
        public string IdExpiryDate { get; set; }
        public Passengers InfantDetails { get; set; }
    }
    public class ContactDetails
    {
        public string MobileNumber { get; set; }
        public string EmailId { get; set; }
        public string Address { get; set; }
    }

    public class PaymentDetails
    {
        public int ModeOfPayment { get; set; }
        public CardDetails CardDetails { get; set; }
    }

    public class CardDetails
    {
        public int CardProvider { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryDate { get; set; }
        public string CurrencyCode { get; set; }
    }

    public class PnrRemarks
    {
        public string RemarkType { get; set; }
        public string RemarkText { get; set; }
    }

    public class GstData
    {
        public string GstNumber { get; set; }
        public string GstOrganizationName { get; set; }
        public string GstEmailId { get; set; }
        public string GstContactNumber { get; set; }
        public string GstAddress1 { get; set; }
        public string GstAddress2 { get; set; }
        public string GstCountry { get; set; }
        public string GstState { get; set; }
        public string GstCity { get; set; }
        public string GstPinCode { get; set; }
    }

    //public class BookingStatus
    //{
    //    public string Status { get; set; }
    //    public string StatusMessage { get; set; }
    //    public string FareChange { get; set; }
    //    public bool IsClassChanged { get; set; }
    //    public string SourceCity { get; set; }
    //    public string DestinationCity { get; set; }
    //    public List<ClassChangeInfo> ClassChangeInfo { get; set; }
    //}
}