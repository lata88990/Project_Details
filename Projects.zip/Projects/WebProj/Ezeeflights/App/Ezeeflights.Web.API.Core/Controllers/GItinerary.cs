﻿using Ezeeflights.Web.API.Core.Services;
using Microsoft.AspNetCore.Mvc;

namespace Ezeeflights.Web.API.Core.Controllers
{
    [ApiController]
    [Route("/api/gitinerary")]
    public class GItinerary : ControllerBase
    {
        private readonly FlightSearchClient flightSearchClient;

        public GItinerary(FlightSearchClient flightSearchClient)
        {
            this.flightSearchClient = flightSearchClient;
        }
        [HttpPost]
        public async Task<IActionResult> Get([FromBody] string data)
        {
            var x = await flightSearchClient.GetGoogleFlights(data);
            if (string.IsNullOrEmpty(x))
            {
                return NotFound();
            }
            return Content(x);
        }
    }
    public class GItineraryModel
    {
        public string Data { get; set; }

    }
}
