﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Text;
using Ezeeflights.Web.API.Core.Helper;
using Ezeeflights.Web.API.Core.Models;
using Ezeeflights.Web.API.Core.Services;
using System.Text.Json;
using Fastlane.Platform.Air.Models.Web;
using System.Net;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Ezeeflights.Web.API.Core.Repo;

namespace Ezeeflights.Web.API.Core.Controllers
{
    [Route("/api/flights")]
    public class FlightsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly FlightSearchClient flightSearchClient;
        private readonly IMailService _mailService;
        private readonly IStorageRepository storageRepository;
        private readonly ILogger<FlightsController> logger;

        public FlightsController(IConfiguration configuration, FlightSearchClient flightSearchClient,
            IMailService mailService, IStorageRepository storageRepository, ILogger<FlightsController> logger)
        {
            _configuration = configuration;
            this.flightSearchClient = flightSearchClient;
            _mailService = mailService;
            this.storageRepository = storageRepository;
            this.logger = logger;
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] FlightSearchModel queryParameters)
        {
            try
            {
                var flightSearch = Common.GetFlightSearch(queryParameters);

                var flightsResult = await flightSearchClient.Search(flightSearch);

                return Ok(flightsResult);

            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
                return NotFound();
            }
        }

        [HttpGet("itinerary")]
        public async Task<ActionResult> Itinerary(FlightItinerarySearchModel flightItinerarySearchModel)
        {
            if (flightItinerarySearchModel != null)
            {

                var flightSearch = Common.GetFlightSearch(flightItinerarySearchModel);
                if (!string.IsNullOrEmpty(flightItinerarySearchModel.SearchId))
                {
                    flightSearch.SearchId = flightItinerarySearchModel.SearchId;
                }
                if (!string.IsNullOrEmpty(flightItinerarySearchModel.TranId))
                {
                    flightSearch.TranId = flightItinerarySearchModel.TranId;
                }
                var flightDetail = await flightSearchClient.GetSelectedFlightDetails(flightSearch);

                if (flightDetail != null)
                {

                    if (!string.IsNullOrEmpty(flightItinerarySearchModel.SearchId))
                    {
                        flightSearch.SearchId = flightItinerarySearchModel.SearchId;
                    }

                    FlightsBookingRQ flightsBooking = new FlightsBookingRQ();
                    flightsBooking.SearchId = flightItinerarySearchModel.SearchId;
                    //flightsBooking.BookingId = idbooking;
                    flightsBooking.Flights = flightDetail;
                    flightsBooking.FlightsSearch = flightSearch;
                    //flightsBooking.SourceMedia = flightsResults.FlightsSearch.SourceMedia;
                    flightsBooking.TranscationStatus = "new";
                    //flightsBooking.FlightsFare = flights.FlightFare;
                    //flightsResult.FlightsSearch.IsDeepLink = false;
                    logger.LogError("[OK] Selected flight found {search}", flightItinerarySearchModel);
                    return Ok(flightsBooking);
                }
                logger.LogError("[ERR] Selected flight not found {search}", flightItinerarySearchModel);

                return BadRequest();
            }
            else
            {
                logger.LogError("[ERR] Search request is NULL");

                return BadRequest();
            }
        }


        [HttpPost("itinerary/save")]
        public async Task<IActionResult> SaveItinerary([FromBody] FlightsBookingRQ flightsBooking)
        {
            try
            {
                if (flightsBooking != null)
                {
                    string emailSubject = string.Empty;

                    var flights = await flightSearchClient.GetSelectedFlightDetails(flightsBooking.FlightsSearch);
                    if (flights != null)
                    {
                        flightsBooking.Flights = flights;
                    }
                    else
                    {
                        logger.LogError("[ERR] Selected Flight not found");
                    }
                    if (string.IsNullOrEmpty(flightsBooking.BookingId))
                    {
                        flightsBooking.BookingId = DateTime.Now.ToString("yyddMMHHmmss");
                        emailSubject = "New flight booking reservation detail Ref:# " + flightsBooking.BookingId;

                        flightsBooking.Status = "pending";
                        await storageRepository.TrySaveResult(flightsBooking);
                    }
                    else
                    {
                        emailSubject = "Payment detail for Ref:# " + flightsBooking.BookingId;
                    }
                    if (!string.IsNullOrEmpty(flightsBooking.FlightsSearch.SourceMedia))
                    {
                        emailSubject += " from Source " + flightsBooking.FlightsSearch.SourceMedia;
                    }
                    var flightsBookingNotification = await Notification(flightsBooking, emailSubject);
                    //else
                    //{
                    //    bookingData = await _context.FlightsBookings.FirstOrDefaultAsync(f => f.BookingId == flightsBooking.BookingId);
                    //    if (bookingData != null)
                    //        _context.Entry(bookingData).State = EntityState.Modified;
                    //}

                    return Ok(new { bookingId = flightsBooking.BookingId });

                }
                else
                {
                    logger.LogError("[ERR] Search request is NULL");
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Exception occured");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

            return BadRequest(flightsBooking);

        }

        private async Task<FlightsBookingRQ> Notification(FlightsBookingRQ flightsBooking, string emailSubject)
        {
            try
            {
                // send ticket email
                MailData mailData = new MailData();
                string ticketBody = "<table style=\"font-family:sans-serif; font-size:12px; width:800px; margin:0 auto;\"><tr><td><img src='https://www.ezeeflights.com/assets/logo-dark.png' width='125' height='36' /></td><td style=\"text-align:right; \">945 Taraval Street, San Francisco, CA 94116,<br> United States of America<br /><b>Phone :</b> 18886040198<br /><b>Email :</b> info@ezeeflights.com</td></tr><tr><td colspan=\"2\"><table style=\"width:100%; font-size:8px; border-collapse:collapse;\">";
                ticketBody += "</table></td></tr><tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td><b>Dear " + flightsBooking.BookerDetail.Title + " " + flightsBooking.BookerDetail.FirstName + " " + flightsBooking.BookerDetail.MiddleName + " " + flightsBooking.BookerDetail.LastName + ",</b><br><br> Thank you for your online order. Ezeeflights will review your online order and one of the Sales consultant will get back to you shortly. Please find your booking summary below. Please note these are not the electronic tickets your electronic tickets will be emailed to you in due course once all the necessary confirmations are obtained from the Airline. If you wish to talk to us then please call us at  <b>18886040198</b>.</td></tr></table></td></tr>";
                ticketBody += "<tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td width=\"50%\"><table style=\"border-spacing:0px 10px;\" cellpadding=\"0\" cellspacing=\"0\"><tr><td style=\"font-weight:bold;\" width=\"150\">Booking Ref :	</td><td style=\"\">" + flightsBooking.BookingId + "</td></tr><tr><td style=\"font-weight:bold;\">Airline :</td><td>" + flightsBooking.Flights?.Airline.Name + "</td></tr><tr><td style=\"font-weight:bold;\">Travel Way :</td><td>" + flightsBooking.FlightsSearch.FlightWay.ToString() + "</td></tr><tr><td style=\"font-weight:bold;\">Cabin :</td><td>" + flightsBooking.FlightsSearch.FlightClass.ToString() + "</td></tr><tr><td style=\"font-weight:bold;\">Departure Date :</td><td>" + flightsBooking.Flights.Outbound[0].DepartureDate.ToString("MMM dd, yyyy HH:mm") + "</td></tr>";

                if (flightsBooking.FlightsSearch.FlightWay == FlightWay.RoundTrip)
                {
                    ticketBody += "<tr><td style=\"font-weight:bold;\">Return Date :</td><td>" + flightsBooking.Flights.Inbound[0].DepartureDate.ToString("MMM dd, yyyy HH:mm") + "</td></tr>";
                }

                //ticketBody += "</table></td><td width=\"50%\" valign=\"bottom\"><table style=\"border-spacing:0px 5px;width:100%;\"><tr><td style=\"font-weight:bold;\">Passenger</td><td style=\"text-align:center; font-weight:bold;\">Qty</td><td style=\"text-align:center; font-weight:bold;\">Price</td><td style=\"text-align:right; font-weight:bold;\">Total</td></tr><tr><td>Adults</td><td style=\"text-align:center;\">" + flightsBooking.FlightsSearch.Adult + "</td><td style=\"text-align:center;\">" + Common.Currency + ((flightsBooking.FlightsFare.AdultFare + flightsBooking.FlightsFare.AdultMarkup) * flightsBooking.FlightsFare.Adult).ToString("0.00") + "</td>";
                ticketBody += "</table></td><td width=\"50%\" valign=\"bottom\"><table style=\"border-spacing:0px 5px;width:100%;\"><tr><td style=\"font-weight:bold;\">Passenger</td><td style=\"text-align:center; font-weight:bold;\">Qty</td><td style=\"text-align:center; font-weight:bold;\">Price</td><td style=\"text-align:right; font-weight:bold;\">Total</td></tr><tr><td>Adults</td><td style=\"text-align:center;\">" + flightsBooking.FlightsSearch.Adult + "</td><td style=\"text-align:center;\">" + _configuration.GetSection("Currency").Value + ((flightsBooking.Flights.FlightFare.AdultFare + flightsBooking.Flights.FlightFare.AdultMarkup)).ToString("0.00") + "</td>";
                ticketBody += "<td style=\"text-align:right;\">" + _configuration.GetSection("Currency").Value + (flightsBooking.Flights.FlightFare.Adult * (flightsBooking.Flights.FlightFare.AdultFare + flightsBooking.Flights.FlightFare.AdultMarkup)).ToString("0.00") + "</td></tr>";

                if (flightsBooking.FlightsSearch.Child > 0)
                {
                    ticketBody += "<tr><td>Childs</td><td style=\"text-align:center;\">" + flightsBooking.FlightsSearch.Child + "</td><td style=\"text-align:center;\">" + _configuration.GetSection("Currency").Value + (flightsBooking.Flights.FlightFare.ChildFare + flightsBooking.Flights.FlightFare.ChildMarkup).ToString("0.00") + "</td><td style=\"text-align:right;\">" + _configuration.GetSection("Currency").Value + (flightsBooking.Flights.FlightFare.Child * (flightsBooking.Flights.FlightFare.ChildFare + flightsBooking.Flights.FlightFare.ChildMarkup)).ToString("0.00") + "</td></tr>";
                }

                if (flightsBooking.FlightsSearch.Infant > 0)
                {
                    ticketBody += "<tr><td>Infant</td><td style=\"text-align:center;\">" + flightsBooking.FlightsSearch.Infant + "</td><td style=\"text-align:center;\">" + _configuration.GetSection("Currency").Value + (flightsBooking.Flights.FlightFare.InfantFare + flightsBooking.Flights.FlightFare.InfantTax + flightsBooking.Flights.FlightFare.InfantMarkup).ToString("0.00") + "</td><td style=\"text-align:right;\">" + _configuration.GetSection("Currency").Value + (flightsBooking.Flights.FlightFare.Infant * (flightsBooking.Flights.FlightFare.InfantFare + flightsBooking.Flights.FlightFare.InfantTax + flightsBooking.Flights.FlightFare.InfantMarkup)).ToString("0.00") + "</td></tr>";
                }
                //ticketBody += "<tr><td>ATOL</td><td style=\"text-align:right;\" colspan=\"3\">" + Common.Currency + flightsBooking.FlightsFare.AtolCharge + "</td></tr><tr><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;\">Total Paid :	</td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + Common.Currency + ((flightsBooking.FlightsFare.GrandTotal + flightsBooking.FlightsFare.AtolCharge).ToString("0.00")) + "</td></tr></table></td></tr></table></td></tr><tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td style=\"font-weight:bold; background:#d7d7d7; padding:5px; font-size:18px\" width=\"50%;\">Passenger Detail</td>";
                ticketBody += "<tr><td> </td><td style=\"text-align:right;\" colspan=\"3\"></td></tr>";
                //                ticketBody += "<tr><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;\">Total Pax Fare :	</td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + Common.Currency + ((flightsBooking.FinalTotalAmt - flightsBooking.FreeChangeAmt)) + "</td></tr>"; mishra
                ticketBody += "<tr><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;\">Total Pax Fare :	</td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + _configuration.GetSection("Currency").Value + (Math.Round((flightsBooking.Flights.FlightFare.GrandTotal), 2)) + "</td></tr>";
                if (Convert.ToInt32(flightsBooking.FreeChangeAmt) > 0)
                {
                    ticketBody += "<tr><td style=\"font-weight:normal; font-size:20px; background:#d7d7d7;\">Free Changes 24 X " + flightsBooking.PassengerDetail.Count + " Pax :	</td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + _configuration.GetSection("Currency").Value + ((flightsBooking.FreeChangeAmt)) + "</td></tr>";
                }
                ticketBody += "<tr><td style=\"font-weight:normal; font-size:20px; background:#d7d7d7;\">&nbsp;	</td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">----------------</td></tr>";
                ticketBody += "<tr><td colspan='6'>&nbsp;&nbsp; </td></tr>";
                // ticketBody += "<tr><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;\">Total Paid : </td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + Common.Currency + ((flightsBooking.FinalTotalAmt)) + "</td></tr>"; mishra
                ticketBody += "<tr><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;\">Total Paid : </td><td style=\"font-weight:bold; font-size:20px; background:#d7d7d7;text-align:right;\" colspan=\"3\">" + _configuration.GetSection("Currency").Value + Math.Round((flightsBooking.Flights.FlightFare.GrandTotal + flightsBooking.FreeChangeAmt + flightsBooking.Flights.FlightFare.AtolCharge), 2) + "</td></tr>";

                ticketBody += "</table></td></tr></table></td></tr><tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td style=\"font-weight:bold; background:#d7d7d7; padding:5px; font-size:18px\" width=\"50%;\">Passenger Detail</td>";
                ticketBody += "<td style=\"font-weight:bold; background:#d7d7d7;font-size:18px; padding:5px;\" width=\"50%;\">Contact Detail</td></tr><tr width=\"50%\"><td valign=\"top\"><table style=\"border-spacing:0px 7px; width:100%\"><tr style=\"text-align:left;\"><th style=\"width:240px;\" align=\"left\">Full Name</th><th style=\"width:110px;\" align=\"left\">Date of Birth</th></tr>";


                foreach (PassengerDetail paxItem in flightsBooking.PassengerDetail)
                {
                    ticketBody += "<tr><td style=\"width:240px;\"> " + paxItem.Title + " " + paxItem.FirstName + " " + paxItem.LastName + " (" + Enum.GetName(paxItem.PassengerType) + ") " + "</td><td style=\"width:110px;\" valign=\"top\">" + paxItem.DOB.ToString("MM-dd-yyyy") + "</td></tr>";
                }

                ticketBody += "</table></td><td width=\"50%\" style=\"vertical-align:top;\"><table style=\"border-spacing:0px 10px; width:350px\"><tr><td style=\"font-weight:bold;\" valign=\"top\" width=\"30%\">Address</td><td>" + flightsBooking.BookerDetail.Address1 + ", " + flightsBooking.BookerDetail.City + ", " + flightsBooking.BookerDetail.Country + " - " + flightsBooking.BookerDetail.PostCode + "</td></tr><tr><td style=\"font-weight:bold;\">Phone :</td><td>" + flightsBooking.PhoneNo + "</td></tr><tr><td style=\"font-weight:bold;\">Email :</td><td>" + flightsBooking.Email + "</td></tr></table></td></tr></table></td></tr>";
                ticketBody += "<tr><td colspan=\"2\"><table style=\"width:100%;background:#f1f1f1;border-collapse: collapse;border: 1px solid #999;\" cellpadding=\"5px\"><tr><td style=\"width:160px; font-size:20px; border-bottom:1px dashed #bbb; font-weight:bold;\">OUTBOUND</td><td style=\"width:160px;border-bottom:1px dashed #bbb;\">" + flightsBooking.Flights.Outbound[0].FromAirport.Code + "<br /> <span style=\"font-size:12px;\">" + flightsBooking.Flights.Outbound[0].FromAirport.CityName + "</span></td><td style=\"width:60px;border-bottom:1px dashed #bbb; text-align:center;\"><img src=\"" + _configuration.GetSection("WebsiteURL").Value + "Content/images/plane.png\" /></td>";
                ticketBody += "<td style=\"width:160px;border-bottom:1px dashed #bbb;text-align:right;\">" + flightsBooking.Flights.Outbound[flightsBooking.Flights.Outbound.Count - 1].ToAirport.Code + " <br /> <span style=\"font-size:12px;\">" + flightsBooking.Flights.Outbound[flightsBooking.Flights.Outbound.Count - 1].ToAirport.CityName + "</span></td><td style=\"width:160px;border-bottom:1px dashed #bbb;\"></td></tr><tr><td style=\"width:350px; font-size:14px; font-weight:bold;\">" + flightsBooking.Flights.Outbound[0].DepartureDate.ToString("FFF MMM dd, yyyy") + "</td><td style=\"width:160px;\"></td><td style=\"width:60px;text-align:center;\"></td><td style=\"width:160px;text-align:right;\"></td>";
                ticketBody += "<td style=\"width:350px; font-size:14px; text-align:right; font-weight:bold;\">Duration: " + (Math.Floor(double.Parse(flightsBooking.Flights.Outbound[flightsBooking.Flights.Outbound.Count - 1].TotalTime) / 60)) + "h " + (double.Parse(flightsBooking.Flights.Outbound[flightsBooking.Flights.Outbound.Count - 1].TotalTime) % 60) + "m </td></tr>";

                int mm = 0;
                foreach (FlightSegment outSegment in flightsBooking.Flights.Outbound)
                {
                    mm++;
                    if (mm != 1)
                    {
                        double stop_time = double.Parse(Common.GetTime(flightsBooking.Flights.Outbound[mm - 1].DepartureDate, flightsBooking.Flights.Outbound[mm - 2].ArrivalDate) + "");
                        ticketBody += "<tr><td style=\"text-align:center;font-size:12px; border-top:1px dashed #bbb; border-bottom:1px dashed #bbb;\" colspan=\"5\"> Stop-Over: " + (Math.Floor(stop_time / 60)) + " Hrs. " + (Math.Floor(stop_time % 60)) + " Mins CHANGE OF PLANE REQUIRED.</td></tr>";
                    }

                    ticketBody += "<tr><td style=\"width:350px; font-size:14px;\"><img src=\"https://www.ezeeflights.com/assets/airlinelogo/" + outSegment.Airline.Code + ".png\" style=\"float:left; padding-right:5px;\" />" + outSegment.Airline.Code + "-" + outSegment.FlightNo + "<br />" + outSegment.Airline.Name + ((!string.IsNullOrEmpty(outSegment.OperatingAirline.Code)) ? "<br />Operated by " + outSegment.OperatingAirline.Name : "") + "</td><td style=\"width:160px;\"><span style=\"font-size:20px;\">" + outSegment.DepartureDate.ToString("HH:mm") + " " + outSegment.FromAirport.Code + "</span> <br /><span style=\"font-size:9px;\">" + outSegment.DepartureDate.ToString("dd MMM") + " " + outSegment.FromTerminal + " " + outSegment.FromAirport.Name + "</span></td>";
                    ticketBody += "<td style=\"width:60px;text-align:center;\"></td><td style=\"width:160px; text-align:right;\"><span style=\"font-size:20px;\">" + outSegment.ArrivalDate.ToString("HH:mm") + " " + outSegment.ToAirport.Code + "</span> <br /><span style=\"font-size:9px;\">" + outSegment.ArrivalDate.ToString("dd MMM") + " " + outSegment.ToTerminal + " " + outSegment.ToAirport.Name + "</span></td><td style=\"width:350px; font-size:12px;text-align:right;\">.<br /><img src=\"" + _configuration.GetSection("WebsiteURL").Value + "Content/images/ticket.png\" width=\"12px\" height=\"12px\" /><span>" + outSegment.CabinClass + "</span></td></tr>";
                }

                if (flightsBooking.FlightsSearch.FlightWay == FlightWay.RoundTrip)
                {
                    ticketBody += "</table></td></tr><tr><td colspan=\"2\"><table style=\"width:100%;border-collapse: collapse;background:#f1f1f1;border: 1px solid #999;\" cellpadding=\"5px\"><tr><td style=\"width:160px; font-size:20px; border-bottom:1px dashed #bbb; font-weight:bold;\">INBOUND</td><td style=\"width:160px;border-bottom:1px dashed #bbb;\">" + flightsBooking.Flights.Inbound[0].FromAirport.Code + "<br /> <span style=\"font-size:12px;\">" + flightsBooking.Flights.Inbound[0].FromAirport.CityName + " </span></td><td style=\"width:60px;border-bottom:1px dashed #bbb; text-align:center;\"><img src=\"" + _configuration.GetSection("WebsiteURL").Value + "Content/images/plane.png\" style=\"transform:rotate(-180deg)\" /></td>";
                    ticketBody += "<td style=\"width:160px;border-bottom:1px dashed #bbb;text-align:right;\">" + flightsBooking.Flights.Inbound[flightsBooking.Flights.Inbound.Count - 1].ToAirport.Code + " <br /> <span style=\"font-size:12px;\">" + flightsBooking.Flights.Inbound[flightsBooking.Flights.Inbound.Count - 1].ToAirport.CityName + "</span></td><td style=\"width:160px;border-bottom:1px dashed #bbb;\"></td></tr><tr><td style=\"width:350px; font-size:14px; font-weight:bold;\">" + flightsBooking.Flights.Inbound[0].DepartureDate.ToString("FFF dd MMM, yyyy") + "</td>";
                    ticketBody += "<td style=\"width:160px;\"></td><td style=\"width:60px;text-align:center;\"></td><td style=\"width:160px;text-align:right;\"></td><td style=\"width:350px; font-size:14px; text-align:right; font-weight:bold;\">Duration: " + (Math.Floor(double.Parse(flightsBooking.Flights.Inbound[flightsBooking.Flights.Inbound.Count - 1].TotalTime) / 60)) + "h " + (double.Parse(flightsBooking.Flights.Inbound[flightsBooking.Flights.Inbound.Count - 1].TotalTime) % 60) + "m</td></tr>";

                    int nn = 0;
                    foreach (FlightSegment inSegment in flightsBooking.Flights.Inbound)
                    {
                        nn++;
                        if (nn != 1)
                        {
                            double stop_time = double.Parse(Common.GetTime(flightsBooking.Flights.Inbound[nn - 1].DepartureDate, flightsBooking.Flights.Inbound[nn - 2].ArrivalDate) + "");
                            ticketBody += "<tr><td style=\"text-align:center;font-size:12px; border-top:1px dashed #bbb; border-bottom:1px dashed #bbb;\" colspan=\"5\"> Stop-Over: " + (Math.Floor(stop_time / 60)) + " Hrs. " + (Math.Floor(stop_time % 60)) + " Mins CHANGE OF PLANE REQUIRED.</td></tr>";
                        }

                        ticketBody += "<tr><td style=\"width:350px; font-size:14px;\"><img src=\"https://www.ezeeflights.com/assets/airlinelogo/" + inSegment.Airline.Code + ".png\" style=\"float:left; padding-right:5px;\" />" + inSegment.Airline.Code + "-" + inSegment.FlightNo + "<br />" + inSegment.Airline.Name + ((!string.IsNullOrEmpty(inSegment.OperatingAirline.Code)) ? "<br />Operated by " + inSegment.OperatingAirline.Name : "") + "</td><td style=\"width:160px;\"><span style=\"font-size:20px;\">" + inSegment.DepartureDate.ToString("HH:mm") + " " + inSegment.FromAirport.Code + "</span> <br /><span style=\"font-size:9px;\">" + inSegment.DepartureDate.ToString("dd MMM") + " " + inSegment.FromTerminal + " " + inSegment.FromAirport.Name + "</span></td><td style=\"width:60px;text-align:center;\"></td>";
                        ticketBody += "<td style=\"width:160px; text-align:right;\"><span style=\"font-size:20px;\">" + inSegment.ArrivalDate.ToString("HH:mm") + " " + inSegment.ToAirport.Code + "</span> <br /><span style=\"font-size:9px;\">" + inSegment.ArrivalDate.ToString("dd MMM") + " " + inSegment.ToTerminal + " " + inSegment.ToAirport.Name + "</span></td><td style=\"width:350px; font-size:12px;text-align:right;\">.<br /><img src=\"" + _configuration.GetSection("WebsiteURL").Value + "Content/images/ticket.png\" width=\"12px\" height=\"12px\" /><span>" + inSegment.CabinClass + "</span></td></tr>";
                    }
                }
                ticketBody += "</table></td></tr>";

                if (flightsBooking.BagPrice != null && int.Parse(flightsBooking.BagPrice.BagsPcs) > 0)
                {
                    ticketBody += "<tr><td colspan =\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\">";
                    ticketBody += "<tr><td style=\"font-weight:bold; background:#d7d7d7; padding:5px; font-size:18px\" width=\"50%;\">Cabin Baggage</td>";
                    ticketBody += "<td style=\"font-weight:bold; background:#d7d7d7;font-size:18px; padding:5px;\" width=\"50%;\">Checked Baggage</td></tr>";
                    ticketBody += "<tr width=50%\"><td valign=\"top\">";
                    ticketBody += "<table style=\"border-spacing:1px 7px; width:100%\"><tr style=\"text-align:left;\">";
                    ticketBody += "<th style=\"width:50px;\" align=\"left\">Qty</th><th style=\"width:150px;\" align=\"left\">Size</th><th style=\"width:50px;\" align=\"left\">Weight</th><th style=\"width:50px;\" align=\"left\">Cost</th></tr>";
                    ticketBody += "<tr><td style=\"width:50px;\">1</td><td style=\"width:150px;\" valign=\"top\">55×20×40 cm</td><td style=\"width:50px;\" valign=\"top\">10 Kg</td><td style=\"width:50px;\" valign=\"top\">$0</td></tr>";
                    ticketBody += "</table></td>";

                    ticketBody += "<table style=\"border-spacing:1px 7px; width:100%\"><tr style=\"text-align:left;\">";
                    ticketBody += "<th style=\"width:50px;\" align=\"left\">Qty</th><th style=\"width:150px;\" align=\"left\">Size</th><th style=\"width:50px;\" align=\"left\">Weight</th><th style=\"width:50px;\" align=\"left\">Cost</th></tr>";
                    ticketBody += "<tr><td style=\"width:50px;\">" + flightsBooking.BagPrice.BagsPcs + "</td><td style=\"width:150px;\" valign=\"top\">78×28×52 cm</td><td style=\"width:50px;\" valign=\"top\">23 Kg</td><td style=\"width:50px;\" valign=\"top\">$" + flightsBooking.BagPrice.BagsPcsPrice + "</td></tr>";
                    ticketBody += "</table></td>";
                    ticketBody += "</tr></table>";
                    ticketBody += "</td></tr>";
                }

                if (Convert.ToInt32(flightsBooking.FreeChangeAmt) > 0)
                {
                    ticketBody += "<tr><td colspan =\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\">";
                    ticketBody += "<tr><td style=\"font-weight:bold; background:#d7d7d7; padding:5px; font-size:18px\" width=\"100%;\">Free Changes</td></tr>";
                    ticketBody += "<tr width=\"100%\"><td valign=\"top\">";
                    ticketBody += "<table style=\"border-spacing:1px 7px; width:100%\"><tr style=\"text-align:left;\">";
                    ticketBody += "<th style=\"width:50px;\" align=\"left\">Pax(s)</th><th style=\"width:150px;\" align=\"left\">Changer</th><th style=\"width:50px;\" align=\"left\">Total Cost</th></tr>";
                    ticketBody += "<tr><td style=\"width:50px;\">" + flightsBooking.PassengerDetail.Count + "</td><td style=\"width:150px;\" valign=\"top\">$24 PP</td><td style=\"width:50px;\" valign=\"top\">$" + 24 * flightsBooking.PassengerDetail.Count + "</td></tr>";
                    ticketBody += "</table></td>";
                    ticketBody += "</tr></table>";
                    ticketBody += "</td></tr>";
                }

                ticketBody += "<tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td colspan=\"2\" style=\"font-weight:bold; font-size:18px; \">Protection Statement</td></tr><tr><td colspan=\"2\" style=\"font-size:12px; \"><p>* This ticket is sold by ezeeflights.com acting as agent for the airline.</p><p># Airline failure protection covers your flight tickets against the failure of the airline; should the airline fail you will be assured of..</p><p>a) A full refund of monies paid for the cost of the original ticket when no travel has begun.</p><p>b) A refund of any additional flight-only costs relating to repatriation to your original point of departure.</p></td></tr></table></td></tr>";
                ticketBody += "<tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td colspan=\"2\" style=\"font-weight:bold; font-size:18px; \">Fare Rules</td></tr><tr><td colspan=\"2\" style=\"font-size:12px; \"><p>By proceeding to book your flights with us, you are agreeing to the following fare rules and conditions. If for any reason you do not agree with any part of the below conditions, you should must not proceed with your booking. By proceeding you are agreeing to these terms of service:</p><p>Changes are only permitted in certain specific circumstances and charges will apply. Please contact us if you need a ticket that can be changed so that we can advise you of any applicable fees or charges.</p>";
                ticketBody += "<p>Whilst we will process all bookings as per your requirements, Please bear in mind that airlines can change your flight schedule and departure time at any time prior to your departure.</p><p>All fares and most taxes are non-refundable. If you no show for your flight and do not cancel your booking ( 48 hours to 72 hours) before departure then there is no refund.</p><p>Tickets are for use of the named person only. They may not be transferred to anyone else and name changes are not permitted.</p><p>Passengers need to be at the airport 3 hours prior to the departure as tickets could not be refunded or changed because of a no show at the airport.</p>";
                ticketBody += "<p>Once you have made your booking, you will receive your flight confirmation by E-mail. Please note that this acknowledgement is not your E-Ticket confirmation that will be sent to you later. If you experience any problems with your booking, please do not rebook as this may result in two bookings being made and duplicate payments being taken. Be patient and we will contact you as soon as possible to assist you further.</p><p>If for any reason you have not received an acknowledgement email or booking confirmation from us within six hours of booking, please contact our sales team on 18886040198. Please ensure that you check your junk and spam mailboxes prior to contacting us as emails can end up here depending on your spam filter settings.</p><p>For all flights We request that you contact your airline in the local country 72 hours prior to departure and please make sure that your flights departure are on time. We will not be responsible for any costs or inconvenience caused by short notice schedule changes and cancellations.</p></td></tr></table></td></tr>";
                ticketBody += "<tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td colspan=\"2\" style=\"font-size:12px; \"><p>Your tickets will be issued and sent by e-mail within 24 hours subject to confirmation of your payment. If you bypassed Verified by Visa authentication additional documentation may be requested to confirm your identity.<br>Please check that all of the flight and / or accommodation information shown on your itinerary are correct, any errors discovered after departure may carry penalties to be corrected.</p><p>The responsibility to ensure that you have the correct and valid travel document along with the necessary visa for your final destination, as well as any transit destinations, is yours; we strongly suggest that you check with the relevant embassy ezeeflights.com can not be held liable for refusal by the airline to board you or any financial loss due to incorrect passport and/or visa documents.</p>";
                ticketBody += "<p>We suggest that you Check-In a minimum of 3 hours prior to departure. On-line check in facilities may be available for your airline, please check in on line where possible as some carriers do charge for airport check in. Always select and pre-pay for checked baggage (if not included) prior to arrival at the airport as additional airport fees may apply. Please refer to the airlines website for further details or contact our customer services.</p><p><b>In the event of a schedule change by the airline, we will make every effort to contact you by e-mail or by phone which you have given us on making the booking. Sometimes, it may not be possible to contact you, So, we strongly recommend that you contact your airline locally at your destination 72 hours prior to departure to reconfirm your flight departure time and do provide your local contact for airline to contact you in case of any delays or changes in your flight departure time.</b></p>";
                ticketBody += "<p>To query any of the details on this itinerary/receipt please contact us at info@ezeeflights.com or by phone 18886040198. If you wish to cancel and apply for a refund please e-mail us at refund@ezeeflights.com; all refunds are subject to the terms and conditions as set by your airline and/or hotel.</p></td></tr></table></td></tr>";
                ticketBody += "<tr><td colspan=\"2\"><table style=\"border:1px solid #999; background-color:#f1f1f1; width:100%;\"><tr><td colspan=\"2\" style=\"font-weight:bold; font-size:14px; \">Any help with your existing booking or any other assistance you may require you can also contact our office below</td></tr><tr><td colspan=\"2\" style=\"font-size:12px; \"><p><b>Helpline No :</b> 18886040198 (Toll-Free) 08am to 11pm (Open All Days)</p></td></tr></table></td></tr></table>";

                //mailData.Subject = emailSubject;
                //mailData.ToEmail = flightsBooking.Email;

                mailData.Body = ticketBody.ToString();
                //await _mailService.SendEmailAsync(mailData);


                string adminTicketBody = "Hello admin,<br><br><b>New flight booking detail as below</b><br><br><b>Customer Name :</b> " + flightsBooking.FullName + "<br><b>Booking Info :</b> " + flightsBooking.FlightsSearch.From + " - " + flightsBooking.FlightsSearch.To + ", " + flightsBooking.Flights.Airline.Code + "<br><b>Payment :</b> Paid/Unpaid <br>" +
                    $"<div>{ticketBody}</div>";
                mailData = new MailData();

                mailData.Subject = emailSubject;
                mailData.Body = adminTicketBody;
                mailData.ToEmail = new string[] { "sales@ezeeflights.com" };
                //if (string.Equals(flightsBooking.FlightsSearch.SourceMedia, "JETCOST", StringComparison.InvariantCultureIgnoreCase))
                //{
                //    mailData.ToEmail = new string[] { "darry@ezeeflights.com",
                //        "john@ezeeflights.com", "rachael@ezeeflights.com","sam@ezeeflights.com",
                //    "antonio@ezeeflights.com","tyler@ezeeflights.com"};
                //}
                //else
                //{
                //    mailData.ToEmail = new string[] { "sales@ezeeflights.com" };
                //}
                mailData.ToBccEmail = "finforcorp@gmail.com";
                await _mailService.SendEmailAsync(mailData);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return flightsBooking;
        }


    }
}
