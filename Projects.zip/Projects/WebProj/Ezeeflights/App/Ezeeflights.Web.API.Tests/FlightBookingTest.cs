using Fastlane.Platform.Air.Models.Web;
using Razorpay.Api;
using System.Net.Sockets;
using System.Text.Json;

namespace Ezeeflights.Web.API.Tests
{
    [TestClass]
    public class FlightBookingTest
    {
        [TestMethod]
        public void Deserialize_FlightBooking_Json_Invalid_Text()
        {
            var x = JsonSerializer.Deserialize<FlightsBookingRQ>(File.ReadAllText("App_Data/flightbooking-invalid.json"));
            Assert.IsNull(x);
        }
        [TestMethod]
        public void Deserialize_FlightBooking_Json_Valid_Text()
        {
            FlightsBookingRQ flightsBooking = new FlightsBookingRQ()
            {
                FlightsSearch = new FlightSearchRQ()
                {
                    Adult = 1,

                }
            };
            var x = JsonSerializer.Deserialize<FlightsBookingRQ>(File.ReadAllText("App_Data/flightbooking-valid.json"));
            Assert.IsNotNull(x);
        }
    }
}