﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ezeeflights.Web.API.Tests
{
    [TestClass]
    public class RazorPayTest
    {
        [TestMethod]
        public void OrderTest()
        {
            var client = new RazorpayClient("rzp_test_A9pp0oLA0t6Ost", "Uhel6AE2qBjzDBRAUQjV3qSO");

            Dictionary<string, object> options = new Dictionary<string, object>
            {
                { "amount", "1000" },
                { "currency", "GBP" },
                { "receipt", Guid.NewGuid() }
            };

            Order order = client.Order.Create(options);

        }
    }
}
