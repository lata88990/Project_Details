using Ezeeflights.Web.API.Core.Controllers;
using Ezeeflights.Web.API.Core.Models;
using Ezeeflights.Web.API.Core.Repo;
using Ezeeflights.Web.API.Core.Services;
using Microsoft.AspNetCore.HttpOverrides;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<MailSettings>(builder.Configuration.GetSection(nameof(MailSettings)));
builder.Configuration
    .AddJsonFile("ocelot.json")
    .AddJsonFile($"ocelot.{builder.Environment.EnvironmentName}.json");


Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .CreateLogger();

builder.Host.UseSerilog();


// Add services to the container.

builder.Services.AddControllers().
    AddApplicationPart(typeof(FlightsController).Assembly);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpClient<FlightSearchClient>((httpClient) =>
{
    httpClient.BaseAddress = new Uri(builder.Configuration["ApiUrl"]);
});
builder.Services.AddTransient<IStorageRepository, FileStorageRepository>();
//.ConfigureHttpMessageHandlerBuilder((c) =>
//{
//    c.PrimaryHandler = new HttpClientHandler()
//    {
//        ClientCertificateOptions = ClientCertificateOption.Manual,
//        ServerCertificateCustomValidationCallback =
//        (httpRequestMessage, cert, cetChain, policyErrors) =>
//        {
//            return true;
//        }
//    };
//});

builder.Services.AddTransient<IMailService, MailService>();

builder.Services.AddOcelot(builder.Configuration);


builder.Services.AddSpaStaticFiles(configuration =>
{
    configuration.RootPath = "wwwroot";
});


//builder.Services.AddHttpLogging(logging =>
//{
//    logging.LoggingFields = HttpLoggingFields.RequestBody;
//    logging.RequestHeaders.Add("X-Api-Key");
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
});

//app.UseHttpLogging();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.UseHttpsRedirection();

app.UseSpaStaticFiles();
app.UseRouting();

app.MapControllers();

app.MapWhen(context => (context.Request.Path.Value != null && context.Request.Path.Value.TrimEnd('/').EndsWith("/api")), appBuilder =>
{
    appBuilder.UseOcelot();
});

app.UseSpa(spa =>
{
    // To learn more about options for serving an Angular SPA from ASP.NET Core,
    // see https://go.microsoft.com/fwlink/?linkid=864501

    spa.Options.SourcePath = "wwwroot";

});

try
{
    Log.Debug("Starting web host");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Host terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}