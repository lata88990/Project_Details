﻿using Ezeeflights.Web.API.Core.Helper;
using Ezeeflights.Web.API.Core.Models;
using Ezeeflights.Web.API.Core.Repo;
using Ezeeflights.Web.API.Core.Services;
using Fastlane.Platform.Air.Models.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Razorpay.Api;

namespace Ezeeflights.Web.UK.API.Controllers
{
    [Route("/api/razorpay")]
    public class RazorPayController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly IStorageRepository storageRepository;
        private readonly IMailService _mailService;

        public RazorPayController(IConfiguration configuration, IMailService mailService, IStorageRepository storageRepository)
        {
            this.configuration = configuration;
            this.storageRepository = storageRepository;
            _mailService = mailService;
        }

        [HttpGet("order")]
        public async Task<IActionResult> Order([FromQuery] string bookingId)
        {
            if (!string.IsNullOrEmpty(bookingId))
            {
                var bookingDetail = await storageRepository.Get(bookingId);
                if (bookingDetail != null)
                {

                    var client = new RazorpayClient(configuration.GetSection("RazorPay:Key").Value, configuration.GetSection("RazorPay:Secret").Value);

                    Dictionary<string, object> options = new Dictionary<string, object>
            {
                { "amount", bookingDetail.Flights.TotalCost * 100 },
                { "currency", "GBP" },
                { "receipt", bookingId }
            };

                    Order order = client.Order.Create(options);
                    return Ok(order);

                }
            }
            return BadRequest();
        }

        [HttpGet("saveorder")]
        public async Task<IActionResult> SaveOrder([FromQuery] string bookingId, string orderId, string status)
        {
            if (!string.IsNullOrEmpty(bookingId))
            {
                var bookingDetail = await storageRepository.Get(bookingId);
                if (bookingDetail != null)
                {
                    await Notification(bookingId, orderId, status);
                    return Ok();

                }
            }
            return BadRequest();
        }

        private async Task<bool> Notification([FromQuery] string bookingId, [FromQuery] string orderId, [FromQuery] string status)
        {
            try
            {
                // send ticket email
                MailData mailData = new MailData();


                string adminTicketBody = "Hello admin,<br><br><b>Payment detail as below</b><br><br><b>Booking Id : </b> " + bookingId + "<br><b>Order Id :</b> " + orderId + "<br><br><b>Payment status:</b>" + status + "<br>";
                mailData = new MailData();

                mailData.Subject = $"Payment Status for booking id {bookingId} is {status}";
                mailData.Body = adminTicketBody;
                mailData.ToEmail = new string[] { "sales@ezeeflights.com" };
                mailData.ToBccEmail = "finforcorp@gmail.com";
                await _mailService.SendEmailAsync(mailData);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}
