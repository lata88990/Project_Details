import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';

const routes: Routes = [{
  path: '',
  component: HomeComponent
}
  , {
  path: 'flights',
  loadChildren: () => import('./flights/flights.module').then(m => m.FlightsModule)
},
{
  path: 'aboutus',
  loadChildren: () => import('./info/about/about.module').then(m => m.AboutModule)
},
{
  path: 'contactus',
  loadChildren: () => import('./info/contact/contact.module').then(m => m.ContactModule)
},
{
  path: 'terms-and-conditions',
  loadChildren: () => import('./info/terms-and-conditions/terms-and-conditions.module').then(m => m.TermsAndConditionsModule)
},
{
  path: 'privacy-policy',
  loadChildren: () => import('./info/privacy-policy/privacy-policy.module').then(m => m.PrivacyPolicyModule)
},
{
  path: 'faq',
  loadChildren: () => import('./info/faq/faq.module').then(m => m.FaqModule)
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'top' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
