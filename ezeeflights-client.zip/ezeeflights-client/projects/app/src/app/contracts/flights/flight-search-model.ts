export interface IFlightSearchModel {
    org: string;
    des: string;
    dDate: string;
    rDate?: string;
    adt: number;
    chld: number;
    inf: number;
    ref: string;
    tCode: string;
    cabin: string;
    trip: number;
    directFlightsOnly: boolean;
}

export interface IFlightItinerarySearchModel extends IFlightSearchModel {
    tranId: string;
    id: string;
}

export const cabins = [{
    text: 'Economy',
    value: 'Y'
}, {
    text: 'Premium Economy',
    value: 'P'
}, {
    text: 'Business',
    value: 'C'
}, {
    text: 'First',
    value: 'F'
}];

export interface IMulticityFlightSearchModel {
    name: string;
    number: string;
    email: string;
    routes: IMulticityFlightSearchRouteModel;
    adt: number;
    chld: number;
    inf: number;
}

export interface IMulticityFlightSearchRouteModel {
    originIATA: string;
    destinationIATA: string;
    departDate: string;
}
