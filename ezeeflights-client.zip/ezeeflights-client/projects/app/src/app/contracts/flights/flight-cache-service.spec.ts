import { TestBed } from '@angular/core/testing';

import { FlightCacheServiceService } from './flight-cache-service';

describe('FlightCacheServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FlightCacheServiceService = TestBed.get(FlightCacheServiceService);
    expect(service).toBeTruthy();
  });
});
