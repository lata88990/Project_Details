import { IFlightSearchModel } from './flight-search-model';

describe('FlightSearchModel', () => {
  it('should create an instance', () => {
    expect({} as IFlightSearchModel).toBeTruthy();
  });
});
