import { FlightSearchForm } from './flight-search-form';

describe('FlightSearchForm', () => {
  it('should create an instance', () => {
    expect(new FlightSearchForm()).toBeTruthy();
  });
});
