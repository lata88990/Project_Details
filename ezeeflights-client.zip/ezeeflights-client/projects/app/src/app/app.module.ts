import { DEFAULT_CURRENCY_CODE, LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NgbDateParserFormatter, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FlightSearchModule } from './components/flight-search/flight-search.module';
import { DatePipe, CurrencyPipe } from '@angular/common';
import { NgbDateUSAParserFormatter } from './contracts/ngb-date-usa-format';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    NgbModule,
    AppRoutingModule,
    FlightSearchModule
  ],
  providers: [DatePipe, CurrencyPipe,
    { provide: NgbDateParserFormatter, useClass: NgbDateUSAParserFormatter },
    { provide: LOCALE_ID, useValue: 'en-US' },
    { provide: DEFAULT_CURRENCY_CODE, useValue: 'USD' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
