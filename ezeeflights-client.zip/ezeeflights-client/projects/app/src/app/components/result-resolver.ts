import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, ParamMap } from "@angular/router";
import { forkJoin, Observable, of } from "rxjs";
import { FlightCacheService } from "../contracts/flights";
import { AppHelper } from "./app-helper";

@Injectable()
export class FlightResultResolver implements Resolve<any[]> {
    constructor(private httpClient: HttpClient, private flightCacheService: FlightCacheService) { }

    resolve(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<any[]> | Promise<any[]> | any[] {
        const from = AppHelper.extractQueryParamValueByKey('from', route.queryParamMap);
        const source = this.httpClient.get<any[]>('/api/airports/match/' + from);
        const to = AppHelper.extractQueryParamValueByKey('to', route.queryParamMap);
        const dest = this.httpClient.get<any[]>('/api/airports/match/' + to);
        return forkJoin<any[]>([of({ code: from, name: this.flightCacheService.airportLookup(from) }),
        of({ code: to, name: this.flightCacheService.airportLookup(to) })])
    }

}