import { AfterViewInit, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppHelper } from '../app-helper';

@Component({
  selector: 'flight-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: {
    'class': 'fsr-loader'
  }
})
export class FlightLoadingComponent implements OnInit, AfterViewInit {
  fromAirport: any;
  toAirport: any;
  flightClass: string | null = null;
  adult = 0;
  child = 0;
  infant = 0;
  flightWay = '';
  departDate = '';
  returnDate: string | null = null;
  constructor(private route: ActivatedRoute) {
    route.data.subscribe((d: any) => {
      this.fromAirport = d.airports[0];
      this.toAirport = d.airports[1];
    })
    route.queryParamMap.subscribe(q => {
      const classData = AppHelper.extractQueryParamValueByKey('flightClass', q);
      if (classData) {
        switch (classData) {
          case '1':
            this.flightClass = 'First Class';
            break;
          case '2':
            this.flightClass = 'Business Class';
            break;
          case '3':
            this.flightClass = 'Premimum Economy Class';
            break;
          case '4':
            this.flightClass = 'Economy Class';
            break;
        }
      }
      this.adult = Number(AppHelper.extractQueryParamValueByKey('adult', q));
      this.child = Number(AppHelper.extractQueryParamValueByKey('child', q));
      this.infant = Number(AppHelper.extractQueryParamValueByKey('infant', q));
      this.flightWay = String(AppHelper.extractQueryParamValueByKey('flightWay', q)) == '2' ? 'Return' : 'Oneway';
      this.departDate = String(AppHelper.extractQueryParamValueByKey('depDate', q));
      this.returnDate = AppHelper.extractQueryParamKey('retDate', q) ? AppHelper.extractQueryParamValueByKey('retDate', q) : null;
    });
  }
  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
  }

}
