import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightLoadingComponent } from './loading.component';


@NgModule({
  declarations: [FlightLoadingComponent],
  imports: [
    CommonModule
  ],
  exports: [FlightLoadingComponent]
})
export class FlightLoadingModule { }
