
export interface StopExtra {
    flightId: string;
    extraType: string;
    airline?: any;
    totalCost: number;
    totalTime: number;
    totalStop: number;
    provider?: any;
}

export interface Airline {
    id: number;
    code: string;
    name: string;
}

export interface BarExtra {
    flightId: string;
    extraType: string;
    airline: Airline;
    totalCost: number;
    totalTime: number;
    totalStop: number;
    provider: string;
}

export interface AirlineExtra {
    flightId?: any;
    extraType: string;
    airline: Airline;
    totalCost: number;
    totalTime: number;
    totalStop: number;
    provider?: any;
}

export interface Airport {
    id: number;
    code: string;
    name: string;
    cityCode: string;
    cityName: string;
    stateCode: string;
    stateName: string;
    countryCode: string;
    countryName: string;
    continent: string;
    latitude: string;
    longtitude: string;
}


export interface FlightsSearch {
    id: number;
    searchId: string;
    from: Airport;
    to: Airport;
    depDate: Date;
    retDate: Date;
    adult: number;
    child: number;
    infant: number;
    flightWay: number;
    flightClass: number;
    airline: Airline;
    isDirect: boolean;
    isFlexi: boolean;
    currency: string;
    siteCode: string;
    sourceMedia: string;
    isDeepLink: boolean;
    apiKey: string;
}

export interface FlightFare {
    adultFare: number;
    adultDiscountValue: number;
    childFare: number;
    infantFare: number;
    adultTax: number;
    adultTaxDiscountValue: number;
    childTax: number;
    infantTax: number;
    avlFr: number;
    adultMarkup: number;
    childMarkup: number;
    infantMarkup: number;
    markupType?: any;
    adult: number;
    child: number;
    infant: number;
    atolCharge: number;
    cardCharge: number;
    avgCost: number;
    grandTotal: number;
}

export interface Airport {
    id: number;
    code: string;
    name: string;
    cityCode: string;
    cityName: string;
    stateCode: string;
    stateName: string;
    countryCode: string;
    countryName: string;
    continent: string;
    latitude: string;
    longtitude: string;
}


export interface ISegment {
    optionRef: string;
    sagementRef: string;
    departureDate: Date;
    arrivalDate: Date;
    fromAirport: Airport;
    toAirport: Airport;
    airline: Airline;
    operatingAirline: Airline;
    fromTerminal: string;
    toTerminal: string;
    flightNo: string;
    equipmentType: string;
    distance: string;
    eTicket: string;
    changePlane: string;
    baggageAllowance: string;
    elapsedTime: string;
    totalTime: string;
    cabinClass: string;
    availability: string;
    bookingCode: string;
    isReturn: boolean;
    markUpType?: any;
    markUp: number;
    flightAmt: number;
    flightTax: number;
}

export interface FlightsListCore {
    provider: string;
    flightId: string;
    sessionId: string;
    flightClass: number;
    airline: Airline;
    currency: string;
    isDeal: boolean;
    deepLink: string;
    totalTime: number;
    totalCost: number;
    markUpType: string;
    stops: number;
    fareRules: string;
    flightFare: FlightFare;
    fareMarkUp?: any;
    outboundMarkUp: number;
    inboundMarkUp: number;
    outboundMarkUpC: number;
    inboundMarkUpC: number;
    worldspanFare: number;
    worldspanTax: number;
    worldspanFareC: number;
    worldspanTaxC: number;
    baglimit?: any;
    listBagsPrice?: any;
    isObSelected?:boolean;
    isIBSelected?: boolean;
}
export interface FlightsList extends FlightsListCore {
    outbound: ISegment[];
    inbound: ISegment[];
    outboundList: any[][];
    inboundList: any[][];
}

export interface FlightFlatList extends FlightsListCore {
    outbound: ISegment[];
    inbound: ISegment[];
}

export interface FlightResultResponse {
    error?: any;
    minPrice: number;
    maxPrice: number;
    stopExtra: StopExtra[];
    barExtra: BarExtra[];
    airlineExtra: AirlineExtra[];
    flightsSearch: FlightsSearch;
    flightsList: FlightsList[];
}

export interface FlightItineraryModel {

    id: number;
    searchId: string;
    bookingId: string;
    transcationId: string;
    pNRNo: string;
    fullName: string;
    email: string;
    phoneNo: string;
    flightsSearch: FlightsSearch;
    flights: FlightsList;
    bookerDetail: BookerDetail;
    passengerDetail: PassengerDetail[];
    paymentDetail: PaymentDetail;
    sagepayDetail: SagepayDetail;
    siteCode: string;
    sourceMedia: string;
    supplierCode: string;
    supplierFare: FlightFare;
    supplierStatus: string;
    supplierComment: string;
    flightsFare: FlightFare;
    agentCode: string;
    paymentStatus: string;
    agentStatus: string;
    agentComment: string;
    adminStatus: string;
    adminComment: string;
    updateFare: boolean;
    worldResponse: string;
    transcationStatus: string;
    isHotel: string;
    status: string;
    timestamp: Date | string;
    bagPrice: BagsPrice;
    freeChangeAmt: number;
    finalTotalAmt: number;

}
export interface BookerDetail {
    title: string;
    firstName: string;
    middleName: string;
    lastName: string;
    phoneNo: string;
    mobileNo: string;
    email: string;
    alternativeEmail: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    country: string;
    postCode: string;
}


export interface PassengerDetail {
    travelerNo: number;
    passengerType: PassengerType;
    title: string;
    firstName: string;
    middleName: string;
    lastName: string;
    DOB: Date | string;
    gender: Gender;
    passportNumber: string;
    nationality: string;
    issueCountry: string;
    expiryDate: Date | string;
}



export interface PaymentDetail {
    cardCode: string;
    cardNumber: string;
    cardHolderName: string;
    expiryMonth: string;
    expiryYear: string;
    cVVNo: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    country: string;
    postCode: string;
}

export interface SagepayDetail {
    bookingId: string;
    transcationId: string;
    cryptVal: string;
    vendorTxCode: string;
    bankAuthCode: string;
    cardType: string;
    cardHolderName: string;
    cardNumber: string;
    cVV: string;
    last4Digits: string;
    expiryDate: string;
    txAuthNo: string;
    vpsTxId: string;
}


export enum PassengerType {
    None = 0,
    Adult = 1,
    Child = 2,
    Infant = 3
}

export enum Gender {
    None = 0,
    Male = 1,
    Female = 2,
}


export interface BagsPrice {
    bagsPcs: string;
    bagsPcsPrice: number;
}