import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StopIndComponent } from './stop-ind.component';

@NgModule({
  declarations: [
    StopIndComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [StopIndComponent]
})
export class StopIndModule { }
