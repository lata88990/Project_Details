import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StopIndComponent } from './stop-ind.component';

describe('StopIndComponent', () => {
  let component: StopIndComponent;
  let fixture: ComponentFixture<StopIndComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StopIndComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopIndComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
