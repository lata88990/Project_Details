import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'flt-stop-ind',
  templateUrl: './stop-ind.component.html',
  styleUrls: ['./stop-ind.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class StopIndComponent implements OnInit {
  @Input() stops: any[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  stopPosition(index: number) {
    return ((1 / (this.stops.length + 1)) * (100 * (index + 1))) - 10 + '%';
  }


  public get stop(): string {
    if (this.stops.length == 1) {
      return 'Nonstop';
    } else if (this.stops.length == 2) {
      return '1 Stop';
    } else {
      return this.stops.length - 1 + ' Stops';
    }
  }

}
