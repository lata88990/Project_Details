import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightSearchPanelComponent } from './search-panel/search-panel.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbDatepickerModule, NgbTypeaheadModule, NgbDropdownModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { FlightCacheService } from '../../contracts/flights/flight-cache-service';
import { FlightSearchPanelBarComponent } from './search-panel-bar/search-panel-bar.component';


@NgModule({
  declarations: [FlightSearchPanelComponent, FlightSearchPanelBarComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgbDatepickerModule,
    NgbTypeaheadModule,
    NgbDropdownModule,
    NgbCollapseModule
  ],
  exports: [FlightSearchPanelComponent, FlightSearchPanelBarComponent],
  providers: [FlightCacheService]

})
export class FlightSearchModule { }
