import { DatePipe } from "@angular/common";
import { FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { NgbDateParserFormatter, NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import * as moment from "moment";
import { DeviceDetectorService } from "ngx-device-detector";
import { Observable, debounceTime, distinctUntilChanged, map } from "rxjs";
import { cabins, FlightCacheService, IFlightSearchModel, SearchBase } from "../../contracts/flights";
import { AppHelper } from "../app-helper";

export abstract class SearchPanelBaseComponent extends SearchBase {

    marketingClass = cabins;

    displayMonths = 2;

    /**
     *
     */
    constructor(fb: FormBuilder,
        router: Router,
        route: ActivatedRoute,
        datePipe: DatePipe,
        flightCacheService: FlightCacheService,
        ngbDateFormat: NgbDateParserFormatter, private deviceService: DeviceDetectorService) {
        super(fb, router, route, datePipe, flightCacheService, ngbDateFormat);
        const isMobile = this.deviceService.isMobile();
        if (isMobile) {
            this.displayMonths = 1;
        }
    }

    search = (text$: Observable<string>) =>
        text$.pipe(
            debounceTime(200),
            distinctUntilChanged(),
            map((term: string) => term.length < 3 ? []
                : this.flightCacheService.airportSource().
                    filter(v => {
                        return v.DisplayName.toLowerCase().indexOf(term.toLowerCase()) > -1 ||
                            v.Code.toLowerCase().indexOf(term.toLowerCase()) > -1;
                    }).slice(0, 10))
        )

    airportFormatter = (x: any) => {
        if (x) {
            return x.DisplayName + '(' + x.Code + ')';
        }
        return '';
    }

    minDepartDate(): NgbDateStruct {
        const date = new Date();
        return { day: date.getDate() + 3, month: date.getMonth() + 1, year: date.getFullYear() };
    }

    onDepartDateSelect(e: any) {
        const returnDate = this.searchFormGroup.get('returnDate');
        if (returnDate) {
            const date = new Date(e.year, e.month - 1, e.day);
            date.setDate(date.getDate() + 7);
            const x = { day: date.getDate(), month: date.getMonth() + 1, year: date.getFullYear() };
            returnDate.setValue(x);
            returnDate.markAsDirty();
        }
    }

    public get minReturnDate(): NgbDateStruct {
        return this.searchFormGroup.get('departureDate')?.value as NgbDateStruct;
    }

    changeClass(d: string) {
        this.searchFormGroup.get('marketingClass')?.setValue(d);
    }

}
