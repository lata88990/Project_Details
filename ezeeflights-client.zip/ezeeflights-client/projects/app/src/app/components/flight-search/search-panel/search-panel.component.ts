import { DatePipe } from '@angular/common';
import { Component, HostBinding } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FlightCacheService } from '../../../contracts/flights';
import { SearchPanelBaseComponent } from '../search-panel-base.component';

@Component({
  selector: 'flight-search-panel',
  templateUrl: './search-panel.component.html',
  styleUrls: ['./search-panel.component.scss']
})
export class FlightSearchPanelComponent extends SearchPanelBaseComponent {


  @HostBinding('class')
  public get class(): string {
    return 'flight-search';
  }

  /**
   *
   */
  constructor(fb: FormBuilder,
    router: Router,
    route: ActivatedRoute,
    datePipe: DatePipe,
    flightCacheService: FlightCacheService,
    ngbDateFormat: NgbDateParserFormatter, deviceService: DeviceDetectorService) {
    super(fb, router, route, datePipe, flightCacheService, ngbDateFormat, deviceService);

  }

}
