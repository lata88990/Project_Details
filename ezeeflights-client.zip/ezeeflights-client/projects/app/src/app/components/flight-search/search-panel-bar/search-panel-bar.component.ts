import { DatePipe } from '@angular/common';
import { Component, HostBinding, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FlightCacheService } from '../../../contracts/flights';
import { SearchPanelBaseComponent } from '../search-panel-base.component';

@Component({
  selector: 'fsp-bar',
  templateUrl: './search-panel-bar.component.html',
  styleUrls: ['./search-panel-bar.component.scss']
})
export class FlightSearchPanelBarComponent extends SearchPanelBaseComponent {

  public isMenuCollapsed = true;

  @HostBinding('class')
  public get class(): string {
    return 'fs-bar';
  }

  /**
   *
   */
  constructor(fb: FormBuilder,
    router: Router,
    route: ActivatedRoute,
    datePipe: DatePipe,
    flightCacheService: FlightCacheService,
    ngbDateFormat: NgbDateParserFormatter, deviceService: DeviceDetectorService) {
    super(fb, router, route, datePipe, flightCacheService, ngbDateFormat, deviceService);

  }

}
