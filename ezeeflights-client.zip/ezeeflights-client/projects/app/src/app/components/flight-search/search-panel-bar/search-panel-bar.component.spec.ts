import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPanelBarComponent } from './search-panel-bar.component';

describe('SearchPanelBarComponent', () => {
  let component: SearchPanelBarComponent;
  let fixture: ComponentFixture<SearchPanelBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchPanelBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPanelBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
