import { AbstractControl, FormGroup } from "@angular/forms";
import { ParamMap } from "@angular/router";

export class AppHelper {

    static extractQueryParamValueByKey(key: string, params: ParamMap) {
        const param = params.keys.find(a => a.toLowerCase() === key.toLowerCase());
        if (param) {
            return params.get(param);
        }
        return '';
    }
    static extractQueryParamKey(key: string, params: ParamMap) {
        return params.keys.find(a => a.toLowerCase() === key.toLowerCase());
    }
    static extractFormControlByKey(key: string, form: FormGroup): AbstractControl | null {
        const k = Object.keys(form.controls).find(a => a.toLowerCase() === key.toLowerCase());
        if (k) {
            return form.get(k);
        }
        return null;
    }
}