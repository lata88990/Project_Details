import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightRoutingModule } from './flight-routing.module';



@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    FlightRoutingModule
  ]
})
export class FlightsModule { }
