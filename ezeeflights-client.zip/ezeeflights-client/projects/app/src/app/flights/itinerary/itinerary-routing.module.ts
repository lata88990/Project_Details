import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightResultResolver } from '../../components/result-resolver';
import { BookingComponent } from './booking.component';
import { ItineraryComponent } from './itinerary.component';
import { PassengerComponent } from './passenger.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [{
  path: '',
  component: ItineraryComponent,
  resolve: {
    airports: FlightResultResolver
  },
  runGuardsAndResolvers: 'paramsOrQueryParamsChange'
},
{
  path: 'payment',
  component: PaymentComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightItineraryRoutingModule { }
