import { Component, OnInit } from '@angular/core';
import { FlightItineraryModel, FlightsList } from '../../../components/contracts';
import { FlightItineraryService } from '../itinerary.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {


  rawResultData: FlightItineraryModel;
  flightItinerary: FlightItineraryModel;

  constructor(private itineraryService: FlightItineraryService) {
    this.flightItinerary = this.itineraryService.flightItinerary;
    this.rawResultData = this.itineraryService.rawResultData;
  }

  ngOnInit(): void {
  }


  public get flight(): FlightsList {
    return this.rawResultData.flights;
  }


}
