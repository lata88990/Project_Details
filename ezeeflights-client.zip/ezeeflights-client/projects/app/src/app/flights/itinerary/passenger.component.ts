import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { AbstractControl, Form, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { FlightsList, PassengerType } from '../../components/contracts';

@Component({
  selector: 'flight-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PassengerComponent implements OnInit, AfterViewInit {

  @Output() next: EventEmitter<any> = new EventEmitter<any>();
  @Input() result: FlightsList | undefined;


  private _form!: FormGroup;
  public get form(): FormGroup {
    return this._form;
  }
  @Input()
  public set form(v: FormGroup) {
    this._form = v;
    this.setYearCollection(v);
  }


  isProcessing = false;

  genders = [
    { text: 'Male', value: 1 },
    { text: 'Female', value: 2 }
  ]

  months = [
    { text: 'Month', value: '' },
    { text: 'January', value: 1 },
    { text: 'Febuary', value: 2 },
    { text: 'March', value: 3 },
    { text: 'April', value: 4 },
    { text: 'May', value: 5 },
    { text: 'June', value: 6 },
    { text: 'July', value: 7 },
    { text: 'August', value: 8 },
    { text: 'September', value: 9 },
    { text: 'October', value: 10 },
    { text: 'November', value: 11 },
    { text: 'December', value: 12 }
  ];

  daysCollection: any[] = [];

  yearsCollection: any[] = [];

  constructor(private http: HttpClient, private fb: FormBuilder, private modalService: NgbModal, private el: ElementRef) {
    this.daysCollection = this.getDaysCollection();
  }

  passportExpiryForm = this.fb.group({ day: '', month: '', year: '' })

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
  }


  getDuration(durationInMinutes: string | number) {
    return (moment.duration(durationInMinutes, "minutes") as any).format("h[h] m[m]");
  }


  getTimeDiff(first: Date, second: Date) {
    const x = moment(second).diff(moment(first), 'minutes');
    return (moment.duration(x, "minutes") as any).format("h [Hrs.] m [Mins]");
  }


  getStopText(stop: number): string {
    if (stop == 1) {
      return 'NonStop';
    } else if (stop == 2) {
      return '1 Stop';
    } else {
      return stop - 1 + ' Stops';
    }
  }


  private getDaysCollection(): any[] {
    const val: any[] = [{ text: 'Day', value: '' }];
    let i = 1;
    while (i < 32) {
      val.push({ text: i.toString(), value: i.toString() });
      i += 1;
    }
    return val;
  }

  private setYearCollection(form: FormGroup) {
    const passengers = this.getPassengerDetailsFormArray();
    for (let index = 0; index < passengers.length; index++) {
      const passenger = passengers.at(index);
      this.yearsCollection.push(this.getYears(passenger));
    }
  }

  private getYears(passenger: AbstractControl): any[] {
    const paxCode = passenger.get('passengerType')?.value;
    const years: any[] = [{ text: 'Year', value: '' }];
    if (paxCode == PassengerType.Adult) {
      const startYear = new Date().getFullYear() - 12;
      const endYear = startYear - 85;
      for (let i = startYear; i > endYear; i--) {
        years.push({ text: i.toString(), value: i.toString() });
      }
    } else if (paxCode == PassengerType.Child) {
      var startYear = new Date().getFullYear() - 2;
      var endYear = startYear - 12;
      for (var i = startYear; i > endYear; i--) {
        years.push({ text: i.toString(), value: i.toString() });
      }
    } else if (paxCode == PassengerType.Infant) {
      var startYear = new Date().getFullYear();
      var endYear = startYear - 3;
      for (var i = startYear; i > endYear; i--) {
        years.push({ text: i.toString(), value: i.toString() });
      }
    }
    return years;
  }

  confirmInfo(content: any) {
    if (this.form.get('passengerDetail')?.valid &&
      this.form.get('phoneNo')?.valid
      && this.form.get('email')?.valid) {
      this.modalService.open(content, { centered: true, scrollable: true });

    } else {
      this.form.get('passengerDetail')?.markAllAsTouched();
      this.form.get('phoneNo')?.markAsTouched();
      this.form.get('email')?.markAsTouched();
      setTimeout(() => {
        const invalidElement = this.el.nativeElement.querySelector('input.ng-invalid,select.ng-invalid');
        if (invalidElement) {
          invalidElement.focus();
          invalidElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 10);
    }
  }
  nextEvent() {
    if (this.isProcessing) {
      return;
    }
    if (this.form.get('passengerDetail')?.valid &&
      this.form.get('phoneNo')?.valid
      && this.form.get('email')?.valid) {
      this.modalService.dismissAll();
      this.isProcessing = true;
      this.http.post('/api/flights/itinerary/save', this.form.value)
        .subscribe({
          next: (d: any): void => {
            this.form.get('bookingId')?.setValue(d.bookingId);
            this.next.next(1);
          },
          complete: () => {
            this.isProcessing = false;
          },
          error: (err: HttpErrorResponse) => {
            this.isProcessing = false;
          }
        })
    } else {
      this.form.get('passengerDetail')?.markAllAsTouched();
      this.form.get('phoneNo')?.markAsTouched();
      this.form.get('email')?.markAsTouched();
      setTimeout(() => {
        const invalidElement = this.el.nativeElement.querySelector('input.ng-invalid,select.ng-invalid');
        if (invalidElement) {
          invalidElement.focus();
          invalidElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 10);
    }
  }

  getPassengerText(passenger: AbstractControl): string {
    let text = '';
    const type = passenger.get('passengerType')?.value;
    switch (type) {
      case PassengerType.Adult:
        text = 'Adult (12+)';
        break;
      case PassengerType.Child:
        text = 'Child (2-12)'
        break;
      case PassengerType.Infant:
        text = 'Infant (0-2)'
        break;
    }
    return text;
  }

  getPassengerDetailsFormArray(): FormArray {
    return this.form.get('passengerDetail') as FormArray;
  }

}
