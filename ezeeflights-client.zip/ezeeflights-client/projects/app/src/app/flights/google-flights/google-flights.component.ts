import { Location } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-google-flights',
  templateUrl: './google-flights.component.html',
  styleUrls: ['./google-flights.component.scss']
})
export class GoogleFlightsComponent implements OnInit {
  hasLoaded = false;
  notFound = false;
  constructor(location: Location, httpClient: HttpClient) {
    const loc = location.path().split('?')
    if (loc && loc.length == 2) {
      httpClient.post(`/api/gitinerary`, JSON.stringify(loc[1]),
        {
          headers: new HttpHeaders().set('Content-Type', 'text/json'),
          responseType: 'text'
        })
        .subscribe({
          next: (d) => {
            window.location.href = d;
          },
          error: () => {
            this.hasLoaded = true;
            this.notFound = true;
          }
        })
    } else {
      this.hasLoaded = true;
      this.notFound = true;
    }
  }

  ngOnInit(): void {
  }

}
