import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoogleFlightsComponent } from './google-flights.component';
import { RouterModule, Routes } from '@angular/router';
import { FlightLoadingModule } from '../../components/loading/flight-loading.module';
import { FlightNotFoundModule } from '../../components/not-found/flight-loading.module';

const routes: Routes = [
  {
    path: '',
    component: GoogleFlightsComponent
  }
]

@NgModule({
  declarations: [
    GoogleFlightsComponent
  ],
  imports: [
    CommonModule,
    FlightLoadingModule,
    FlightNotFoundModule,
    RouterModule.forChild(routes)
  ]
})
export class GoogleFlightsModule { }
