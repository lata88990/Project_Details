import * as moment from "moment";
import { FlightFlatList, ISegment, FlightResultResponse } from "../../components/contracts";


export interface IAirlineFilter {
    code: string;
    name: string;
    price: number;
    selected: boolean;
}

export interface IPriceMinMaxFilter {
    minPrice: number;
    maxPrice: number;
}


export interface IStopOverFilter {
    name: string;
    value: number;
    price: number;
    selected: boolean;
}

export interface ITimeFilter {
    from: number,
    to: number
}

export interface ISortCategory {
    cheapest: ISortProperty;
    fastest: ISortProperty;
    bestValue: ISortProperty;
}

export interface ISortProperty {
    price: number;
    duration: number
    stop: number;
}

export class AirinesFilterCriteria {
    static upSert(flightsList: FlightFlatList, airlineFilters: IAirlineFilter[]): void {
        const record = airlineFilters.find(a => a.code == flightsList.airline.code);
        if (record) {
            if (record.price > flightsList.flightFare.adultFare) {
                record.price = flightsList.flightFare.adultFare;
            }
        } else {
            airlineFilters.push({ code: flightsList.airline.code, name: flightsList.airline.name, price: flightsList.flightFare.adultFare, selected: true });
        }
    }

    static validate(flightsList: FlightFlatList, selectedAirlines: IAirlineFilter[]) {
        return selectedAirlines.findIndex(a => a.code == flightsList.airline.code) >= 0;
    }
}


export class PriceMinMaxFilterCriteria {
    static upSert(flightsList: FlightFlatList, priceFilter: IPriceMinMaxFilter): void {
        if (priceFilter.minPrice == 0) {
            priceFilter.minPrice = flightsList.flightFare.adultFare;
            priceFilter.maxPrice = flightsList.flightFare.adultFare;
        } else {
            if (priceFilter.minPrice > flightsList.flightFare.adultFare) {
                priceFilter.minPrice = flightsList.flightFare.adultFare;
            }
            if (priceFilter.maxPrice < flightsList.flightFare.adultFare) {
                priceFilter.maxPrice = flightsList.flightFare.adultFare;
            }
        }
    }
    static validate(flightsList: FlightFlatList, priceRange: IPriceMinMaxFilter) {
        return flightsList.flightFare.adultFare >= priceRange.minPrice && flightsList.flightFare.adultFare <= priceRange.maxPrice;
    }
}


export class StopFilterCriteria {
    static upSert(flightsList: FlightFlatList, stopFilters: IStopOverFilter[]): void {
        let outBoundLength = flightsList.outbound.length;
        if (outBoundLength > 2) {
            outBoundLength = 3;
        }
        const record = stopFilters.find(a => a.value == outBoundLength);
        if (record) {
            if (record.price > flightsList.flightFare.adultFare) {
                record.price = flightsList.flightFare.adultFare;
            }
        } else {
            switch (outBoundLength) {
                case 1:
                    stopFilters.push({ name: 'Nonstop', price: flightsList.flightFare.adultFare, value: 1, selected: true });
                    break;
                case 2:
                    stopFilters.push({ name: '1 Stop', price: flightsList.flightFare.adultFare, value: 2, selected: true });
                    break;
                case 3:
                    stopFilters.push({ name: '2+ Stop', price: flightsList.flightFare.adultFare, value: 3, selected: true });
                    break;
            }
        }
    }

    static validate(flightsList: FlightFlatList, selectedStopOvers: IStopOverFilter[]) {
        if (selectedStopOvers.length == 3) {
            return true;
        }
        let outBoundLength = flightsList.outbound.length;
        if (outBoundLength > 2) {
            outBoundLength = 3;
        }
        let inBoundLength = flightsList.inbound?.length;
        if (inBoundLength > 2) {
            inBoundLength = 3;
        }
        return selectedStopOvers.findIndex(a => a.value == outBoundLength && (inBoundLength == undefined || (inBoundLength > 0 && a.value == inBoundLength))) >= 0;
    }
}

export class SortCriteria {
    static upSert(flightsList: FlightFlatList, sortCategory: ISortCategory): void {
        let outBoundLength = flightsList.outbound.length;
        if (outBoundLength > 2) {
            outBoundLength = 3;
        }
        if (sortCategory.cheapest.price > flightsList.flightFare.adultFare) {
            sortCategory.cheapest.price = flightsList.flightFare.adultFare;
            sortCategory.cheapest.duration = flightsList.totalTime;
            sortCategory.cheapest.stop = outBoundLength;
        }

        if (sortCategory.fastest.duration > flightsList.totalTime) {
            sortCategory.fastest.price = flightsList.flightFare.adultFare;
            sortCategory.fastest.duration = flightsList.totalTime;
            sortCategory.fastest.stop = outBoundLength;
        }

    }
}

export class TimeFilterCriteria {

    static validate(segment: ISegment, selectedTimeFilters: ITimeFilter[]) {
        let isValidFlight = false;
        if (selectedTimeFilters && selectedTimeFilters.length > 0) {
            const hour = moment(segment.departureDate).hour();
            selectedTimeFilters.forEach(selectedTimeFilter => {
                if (hour > selectedTimeFilter.from && hour < selectedTimeFilter.to) {
                    isValidFlight = true;
                    return;
                }
            });

        } else {
            isValidFlight = true;
        }
        return isValidFlight;
    }
}

export class FlightFilterRow {
    static validate(obSegments: ISegment[], ibSegments: ISegment[], flightFlatList: FlightFlatList): boolean {
        flightFlatList.isObSelected = false;
        flightFlatList.isIBSelected = false;

        let isValid = true;
        if (obSegments.length > 0) {
            isValid = false;
            if (flightFlatList.outbound.length == obSegments.length) {
                let matched = 0;
                flightFlatList.outbound.forEach((s: any, si: any) => {
                    obSegments[si].sagementRef == s.sagementRef ? matched++ : matched == 0;
                });
                if (matched == flightFlatList.outbound.length) {
                    flightFlatList.isObSelected = true;
                    isValid = true;
                }
            }
        }
        if (isValid && ibSegments.length > 0) {
            isValid = false;
            if (flightFlatList.inbound.length == ibSegments.length) {
                let matched = 0;
                flightFlatList.inbound.forEach((s: any, si: any) => {
                    ibSegments[si].sagementRef == s.sagementRef ? matched++ : matched == 0;
                });
                if (matched == flightFlatList.inbound.length) {
                    flightFlatList.isIBSelected = true;
                    isValid = true;
                }
            }
        }
        return isValid;
    }
}


export class FlightSearchResult {
    /**
     * static Transform
     */
    public static Transform(flightResultResponse: FlightResultResponse): FlightFlatList[] {
        var responseDataCollection: FlightFlatList[] = [];
        if (flightResultResponse && flightResultResponse.flightsList && flightResultResponse.flightsList.length > 0) {
            // flightResultResponse.flightsList.forEach((v) => {
            //     if (v.outboundList && v.outboundList.length > 0 && v.inboundList && v.inboundList.length > 0) {
            //         v.outboundList.forEach(o => {
            //             v.inboundList.forEach((i) => {
            //                 const responseData: FlightFlatList = {} as any;

            //                 responseData.airline = v.airline;
            //                 responseData.baglimit = v.baglimit;
            //                 responseData.currency = v.currency;
            //                 responseData.deepLink = v.deepLink;
            //                 responseData.fareMarkUp = v.fareMarkUp;
            //                 responseData.fareRules = v.fareRules;
            //                 responseData.flightClass = v.flightClass;
            //                 responseData.flightFare = v.flightFare;
            //                 responseData.flightId = v.flightId;
            //                 responseData.inbound = i;
            //                 responseData.inboundMarkUp = v.inboundMarkUp;
            //                 responseData.inboundMarkUpC = v.inboundMarkUpC;
            //                 responseData.isDeal = v.isDeal;
            //                 responseData.listBagsPrice = v.listBagsPrice;
            //                 responseData.markUpType = v.markUpType;
            //                 responseData.outbound = o;
            //                 responseData.outboundMarkUp = v.outboundMarkUp;
            //                 responseData.outboundMarkUpC = v.outboundMarkUpC;
            //                 responseData.provider = v.provider;
            //                 responseData.sessionId = v.sessionId;
            //                 responseData.stops = v.stops;
            //                 responseData.totalCost = v.totalCost;
            //                 responseData.totalTime = v.totalTime;
            //                 responseData.worldspanFare = v.worldspanFare;
            //                 responseData.worldspanFareC = v.worldspanFareC;
            //                 responseData.worldspanTax = v.worldspanTax;
            //                 responseData.worldspanTaxC = v.worldspanTaxC;

            //                 responseDataCollection.push(responseData);
            //             })
            //         })
            //     }
            // });
            return flightResultResponse.flightsList;
        }
        return responseDataCollection;
    }
}