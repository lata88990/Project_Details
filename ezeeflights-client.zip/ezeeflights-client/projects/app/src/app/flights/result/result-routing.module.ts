import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightResultResolver } from '../../components/result-resolver';
import { FlightResultComponent } from './result.component';

const routes: Routes = [{
  path: '',
  component: FlightResultComponent,
  resolve: {
    airports: FlightResultResolver
  },
  runGuardsAndResolvers: 'paramsOrQueryParamsChange'
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightResultRoutingModule { }
