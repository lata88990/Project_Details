import { AfterViewInit, Component, OnInit, ViewEncapsulation } from '@angular/core';
import * as moment from 'moment';
import { AirinesFilterCriteria, FlightFilterRow, FlightSearchResult, IAirlineFilter, IPriceMinMaxFilter, ISortCategory, IStopOverFilter, ITimeFilter, PriceMinMaxFilterCriteria, SortCriteria, StopFilterCriteria, TimeFilterCriteria } from './flight-result-helper';
import 'moment-duration-format';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { FlightFlatList, ISegment } from '../../components/contracts';
import { FlightCacheService, IFlightSearchModel } from '../../contracts/flights';
import { ChangeContext, LabelType, Options } from '@angular-slider/ngx-slider';
import { CurrencyPipe } from '@angular/common';

@Component({
  selector: 'flight-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FlightResultComponent implements OnInit, AfterViewInit {

  rawResultData: any = undefined;
  resultData: FlightFlatList[] = [];
  transformedResultData: FlightFlatList[] = [];
  filteredResultData: FlightFlatList[] = [];
  hasLoaded = false;

  //filters collection
  airlineFilters: IAirlineFilter[] = [];
  priceFilter: IPriceMinMaxFilter = { minPrice: 0, maxPrice: 0 };
  stopOverFilters: IStopOverFilter[] = [];
  outBoundTimeFilters: ITimeFilter[] = [];
  inBoundTimeFilters: ITimeFilter[] = [];
  toAirport: any;

  obRowSelected: ISegment[] = [];
  ibRowSelected: ISegment[] = [];

  //sort

  sortCategories: ISortCategory = { cheapest: { duration: Number.MAX_VALUE, price: Number.MAX_VALUE, stop: 0 }, fastest: { duration: Number.MAX_VALUE, price: Number.MAX_VALUE, stop: 0 }, bestValue: { duration: Number.MAX_VALUE, price: Number.MAX_SAFE_INTEGER, stop: 0 } };

  // pricing slider options

  minValue: number = 0;
  maxValue: number = 0;

  options: Options = {
  };

  flightSearchCriteria!: IFlightSearchModel;

  isFilterCollapsed = true;

  constructor(private httpClient: HttpClient, route: ActivatedRoute, private router: Router,
    private flightCacheService: FlightCacheService, private currencyPipe: CurrencyPipe) {
    route.data.subscribe((d: any) => {
      this.toAirport = d.airports[1];
    })
    route.queryParamMap.subscribe(v => {
      this.cleanBeforeSearch();
      this.searchFlight((v as any).params);
    });
  }
  ngAfterViewInit(): void {

  }

  ngOnInit(): void {

  }

  selectFlight(result: FlightFlatList) {
    this.router.navigate(['/flights/itinerary'], {
      queryParams: {
        searchId: this.rawResultData.flightsSearchRQ.searchId,
        tranId: result.flightId
      }, queryParamsHandling: 'merge'
    })
  }

  private searchFlight(params: any) {

    this.httpClient.get('/api/flights/search', { params: params }).subscribe({
      next: (resultData) => {
        this.rawResultData = resultData;
        this.transformedResultData = FlightSearchResult.Transform(resultData as any);
        this.transformedResultData.forEach(flightResult => {
          AirinesFilterCriteria.upSert(flightResult, this.airlineFilters);
          PriceMinMaxFilterCriteria.upSert(flightResult, this.priceFilter);
          StopFilterCriteria.upSert(flightResult, this.stopOverFilters);
          SortCriteria.upSert(flightResult, this.sortCategories);
        });
        this.minValue = this.priceFilter.minPrice;
        this.maxValue = this.priceFilter.maxPrice;

        this.options = {
          floor: this.minValue,
          ceil: this.maxValue,
          translate: (value: number, label: LabelType): string => {
            switch (label) {
              case LabelType.Low:
                return this.currencyPipe.transform(value, '', 'symbol-narrow', '2.2-2') as any;
              case LabelType.High:
                return this.currencyPipe.transform(value, '', 'symbol-narrow', '2.2-2') as any;
              default:
                return this.currencyPipe.transform(value, '', 'symbol-narrow', '2.2-2') as any;
            }
          }
        };

        this.airlineFilters = this.airlineFilters.sort((a, b) => a.name.localeCompare(b.name));
        this.stopOverFilters = this.stopOverFilters.sort((a, b) => a.value - b.value);
        this.transformedResultData = this.transformedResultData.sort((a, b) => a.flightFare.adultFare - b.flightFare.adultFare);
        this.applyLogic();
        this.hasLoaded = true;
        setTimeout(() => {
          this.reBindView();
        }, 500);
      },
      error: () => {
        this.hasLoaded = true;
      }
    });
  }

  applyLogic(): void {
    this.applyFilters();
    this.resultData = this.filteredResultData.slice(undefined, 20);
  }

  loadMore(e: Event): void {
    this.resultData = this.filteredResultData.slice(undefined, this.filteredResultData.length + 20);
    e.preventDefault();
  }

  private applyFilters() {
    this.filteredResultData = [];
    this.transformedResultData.forEach(flightResult => {
      if (AirinesFilterCriteria.validate(flightResult, this.airlineFilters.filter(a => a.selected))
        && StopFilterCriteria.validate(flightResult, this.stopOverFilters.filter(a => a.selected))
        && TimeFilterCriteria.validate(flightResult.outbound[0], this.outBoundTimeFilters)
        && (flightResult.inbound == undefined || (flightResult.inbound && flightResult.inbound.length > 0 &&
          TimeFilterCriteria.validate(flightResult.inbound[0], this.inBoundTimeFilters)))
        && (PriceMinMaxFilterCriteria.validate(flightResult, this.priceFilter))
        && FlightFilterRow.validate(this.obRowSelected, this.ibRowSelected, flightResult)) {
        this.filteredResultData.push(flightResult);
      }
    });
  }

  filterRoute(e: any, segments: ISegment[], direction: string) {
    if (e.target.checked) {
      if (direction == 'outbound') {
        this.obRowSelected = segments;
      } else {
        this.ibRowSelected = segments;
      }
    } else {
      if (direction == 'outbound') {
        this.obRowSelected = [];
      } else {
        this.ibRowSelected = [];
      }
    }
    this.applyLogic();
  }

  togglefltdtl(ctrl: HTMLElement) {
    if (ctrl.classList.contains('d-none')) {
      ctrl.classList.remove('d-none');
      ctrl.classList.add('d-inline');
    } else {
      ctrl.classList.remove('d-inline');
      ctrl.classList.add('d-none');
    }
  }

  reBindView() {

  }

  getDuration(durationInMinutes: string | number) {
    return (moment.duration(durationInMinutes, "minutes") as any).format("h[h] m[m]");
  }


  getTimeDiff(first: Date, second: Date) {
    const x = moment(second).diff(moment(first), 'minutes');
    return (moment.duration(x, "minutes") as any).format("h [Hrs.] m [Mins]");
  }

  getStopText(stop: number): string {
    if (stop == 1) {
      return 'Nonstop';
    } else if (stop == 2) {
      return '1 Stop';
    } else {
      return stop - 1 + ' Stops';
    }
  }

  getClassText(classData: number) {
    let flightClass = '';
    switch (classData) {
      case 1:
        flightClass = 'First Class';
        break;
      case 2:
        flightClass = 'Business Class';
        break;
      case 3:
        flightClass = 'Premimum Economy Class';
        break;
      case 4:
        flightClass = 'Economy Class';
        break;
    }
    return flightClass;
  }

  getAirlineName(code: string) {
    return this.flightCacheService.airLineLookup(code);
  }


  getAirportName(code: string) {
    return this.flightCacheService.airportLookup(code);
  }

  applyAirlineOnly(airline: IAirlineFilter) {
    this.airlineFilters.map(a => { a.selected = false });
    airline.selected = true;
    this.applyLogic();
  }

  resetStopOverFilters() {
    this.stopOverFilters.map(a => a.selected = true);
    this.applyLogic();
  }

  applyOutboundTimeFilter(from: number, to: number) {
    this.applyTimeFilters(this.outBoundTimeFilters, from, to);
  }

  applyinboundTimeFilter(from: number, to: number) {
    this.applyTimeFilters(this.inBoundTimeFilters, from, to);
  }
  private applyTimeFilters(timeFilters: ITimeFilter[], from: number, to: number) {
    const i = timeFilters.findIndex(t => t.from == from);
    if (i > -1) {
      timeFilters.splice(i, 1);
    } else {
      timeFilters.push({ from: from, to: to });
    }
    this.applyLogic();
  }

  resetTimeFilter(filters: ITimeFilter[], elm: string) {
    filters.splice(0);
    document.querySelectorAll(elm + ' input[type="checkbox"]').forEach((e: any) => {
      e.checked = false;
    });
    //$(elm).find('label.active').removeClass('active');
    this.applyLogic();
  }

  clearAirlineFilter() {
    this.airlineFilters.map(a => a.selected = true);
    this.applyLogic();
  }

  cleanBeforeSearch() {
    this.hasLoaded = false;
    this.rawResultData = null;
    this.resultData = [];
    this.filteredResultData = [];
    this.transformedResultData = [];
    this.minValue = 0;
    this.maxValue = 0;

    this.airlineFilters = [];
    this.priceFilter = { minPrice: 0, maxPrice: 0 };
    this.stopOverFilters = [];
    this.outBoundTimeFilters = [];
    this.inBoundTimeFilters = [];
    this.sortCategories = { cheapest: { duration: Number.MAX_VALUE, price: Number.MAX_VALUE, stop: 0 }, fastest: { duration: Number.MAX_VALUE, price: Number.MAX_VALUE, stop: 0 }, bestValue: { duration: Number.MAX_VALUE, price: Number.MAX_SAFE_INTEGER, stop: 0 } };
  }


  onUserChangeEnd(changeContext: ChangeContext): void {
    this.priceFilter.minPrice = changeContext.value;
    this.priceFilter.maxPrice = Number(changeContext.highValue);
    this.applyLogic();
  }

  onSortChanged(d: any) {
    if (d == 'Cheapest') {
      this.transformedResultData = this.transformedResultData.sort((a, b) => a.flightFare.adultFare - b.flightFare.adultFare);
      this.applyLogic();
    } else if (d == 'Quickest') {
      this.transformedResultData = this.transformedResultData.sort((a, b) => a.totalTime - b.totalTime);
      this.applyLogic();
    }
  }

  onApplyFilters() {
    this.isFilterCollapsed = !this.isFilterCollapsed;
    setTimeout(() => {
      window.scroll(0, 0);
    }, 500);
  }
}
