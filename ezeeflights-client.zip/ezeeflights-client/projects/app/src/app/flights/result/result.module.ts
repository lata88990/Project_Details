import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightResultComponent } from './result.component';
import { FlightResultRoutingModule } from './result-routing.module';
import { FlightSearchModule } from '../../components/flight-search/flight-search.module';
import { FlightLoadingModule } from '../../components/loading/flight-loading.module';
import { FlightNotFoundModule } from '../../components/not-found/flight-loading.module';
import { FlightResultResolver } from '../../components/result-resolver';
import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { StopIndModule } from '../../components/stop-ind/stop-ind.module';
import { NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    FlightResultComponent
  ],
  imports: [
    CommonModule,
    NgxSliderModule,
    NgbCollapseModule,
    FlightSearchModule,
    FlightLoadingModule,
    FlightNotFoundModule,
    StopIndModule,
    FlightResultRoutingModule
  ],
  providers: [FlightResultResolver]
})
export class FlightResultModule { }
