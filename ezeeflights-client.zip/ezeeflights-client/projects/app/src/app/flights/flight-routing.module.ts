import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path: 'result',
  loadChildren: () => import('./result/result.module').then(m => m.FlightResultModule)
}
  , {
  path: 'itinerary',
  loadChildren: () => import('./itinerary/itinerary.module').then(m => m.FlightItineraryModule)
},
{
  path: 'gitinerary',
  loadChildren: () => import('./google-flights/google-flights.module').then(m => m.GoogleFlightsModule)
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightRoutingModule { }
