import { Directive, Input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FlightCacheService } from './flight-cache-service';
import { NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { IFlightSearchModel } from './flight-search-model';
import { FlightSearchForm } from './flight-search-form';
import { FormUtilities } from '../form-utilities';

@Directive()
export abstract class SearchBase {
    _flightSearchModel!: IFlightSearchModel;
    private flightSearchForm: FlightSearchForm;

    public searchFormGroup: FormGroup;

    marketingClassText: string = 'Economy';

    hasReturnTrip: boolean = true;

    minInfant = 0;
    maxInfant = 1;

    public get passengerText(): string {
        const formValue = this.searchFormGroup.value;
        let txt = formValue.adultCount + (formValue.adultCount == 1 ? ' Adult' : ' Adults');
        if (formValue.childCount > 0) {
            txt += ', ' + formValue.childCount + (formValue.childCount == 1 ? ' Child' : ' Children');
        }
        if (formValue.infantCount > 0) {
            txt += ', ' + formValue.infantCount + (formValue.infantCount == 1 ? ' Infant' : ' Infants');
        }
        return txt;
    }


    @Input()
    public get flightSearchModel(): IFlightSearchModel {
        return this._flightSearchModel;
    }


    public set flightSearchModel(v: IFlightSearchModel) {
        this._flightSearchModel = v;
        if (v && v.org) {
            const orgAirport = v.org ? this.flightCacheService.airportSource().find(p => p.Code.toLowerCase() === v.org.toLowerCase()) : '';
            const desAirport = v.des ? this.flightCacheService.airportSource().find(p => p.Code.toLowerCase() === v.des.toLowerCase()) : '';
            this.flightSearchForm.updateFormGroup(v, orgAirport, desAirport);
            this.hasReturnTrip = v.rDate ? true : false;
        }
    }


    /**
     *
     */
    constructor(private fb: FormBuilder,
        private router: Router,
        private route: ActivatedRoute,
        private datePipe: DatePipe,
        public flightCacheService: FlightCacheService,
        private ngbDateFormatter: NgbDateParserFormatter) {
        this.flightSearchForm = new FlightSearchForm(this.fb);
        this.searchFormGroup = this.flightSearchForm.generateFormGroup();
        this.searchFormGroup.get('marketingClass')?.valueChanges.subscribe(s => {
            //TODO: change it
            //this.marketingClassText = IATAAirResponseHelper.getCabinClassTextFromUI(s);
        });
        this.searchFormGroup.get('adultCount')?.valueChanges.subscribe(s => {
            this.maxInfant = s;
            const infantCountControl = this.searchFormGroup.get('infantCount');
            if (infantCountControl && s < infantCountControl.value) {
                infantCountControl.setValue(s);
            }
        });

        route.queryParamMap.subscribe(v => {
            this.flightSearchModel = this.extractUrlParams(v);
        });
    }


    /**
     * doSearch
     */
    public doSearch(): void {
        if (this.searchFormGroup.valid) {
            this.router.navigate(['flights/result'], { queryParams: this.prepareSearchParams() });
        } else {
            FormUtilities.validateAllFormFields(this.searchFormGroup);
        }
    }

    private prepareSearchParams(): IFlightSearchModel {
        const searchModel = this.searchFormGroup.value;
        return {
            org: searchModel.origin.Code,
            des: searchModel.destination.Code,
            dDate: this.formatDate(searchModel.departureDate),
            rDate: this.hasReturnTrip ? this.formatDate(searchModel.returnDate) : '',
            adt: searchModel.adultCount,
            chld: searchModel.childCount,
            inf: searchModel.infantCount,
            cabin: searchModel.marketingClass
        } as IFlightSearchModel;
    }


    public setReturnDate(data: any, element: any): void {
        if (data === 1) {
            element.disabled = true;
            this.hasReturnTrip = false;
        } else {
            element.disabled = false;
            this.hasReturnTrip = true;
        }
        this.searchFormGroup.get('trip')?.setValue(data);
    }


    public get childCount(): number {
        return this.searchFormGroup.get('childCount')?.value;
    }

    private formatDate(date: NgbDateStruct): string {
        return `${date.year}-${date.month}-${date.day}`;
    }


    private extractUrlParams(params: ParamMap): IFlightSearchModel {
        return {
            adt: + this.extractQueryParamValueByKey('adt', params),
            cabin: this.extractQueryParamValueByKey('cabin', params),
            chld: + this.extractQueryParamValueByKey('chld', params),
            des: this.extractQueryParamValueByKey('des', params),
            dDate: this.extractQueryParamValueByKey('dDate', params),
            directFlightsOnly: Boolean(this.extractQueryParamValueByKey('directFlightsOnly', params)),
            inf: + this.extractQueryParamValueByKey('inf', params),
            org: this.extractQueryParamValueByKey('org', params),
            rDate: this.extractQueryParamValueByKey('rDate', params),
            ref: this.extractQueryParamValueByKey('ref', params),
            tCode: this.extractQueryParamValueByKey('tCode', params),
            trip: + this.extractQueryParamValueByKey('trip', params)

        };
    }

    extractQueryParamValueByKey(key: string, params: ParamMap) {
        const param = params.keys.find(a => a.replace('amp;', '').toLowerCase() === key.toLowerCase());
        if (param) {
            return params.get(param) ?? '';
        }
        return '';
    }

}
