import { FlightSearchBase } from './flight-search-base';

describe('FlightSearchBase', () => {
  it('should create an instance', () => {
    expect(new FlightSearchBase()).toBeTruthy();
  });
});
