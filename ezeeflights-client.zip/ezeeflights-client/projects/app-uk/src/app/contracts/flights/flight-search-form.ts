import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';

import { DatePipe } from '@angular/common';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { IFlightSearchModel } from './flight-search-model';

export class FlightSearchForm {
    private searchFormGroup!: FormGroup;

    /**
     *
     */
    constructor(private formBuilder: FormBuilder) {

    }

    public generateFormGroup(): FormGroup {
        this.searchFormGroup = this.formBuilder.group({
            origin: ['', Validators.required],
            destination: ['', Validators.required],
            departureDate: [this.convertDate(new Date(new Date().setDate(new Date().getDate() + 7))), Validators.required],
            returnDate: [this.convertDate(new Date(new Date().setDate(new Date().getDate() + 14)))],
            adultCount: [1],
            childCount: [0],
            infantCount: [0],
            marketingClass: ['Economy'],
            trip: ['0']
        });
        return this.searchFormGroup;
    }
    private convertDate(date: Date): NgbDateStruct {
        return { day: date.getDate(), month: date.getMonth() + 1, year: date.getFullYear() };
    }


    /**
     * name
     */
    public updateFormGroup(model: IFlightSearchModel, orgPlace: any, desPlace: any): void {
        if (model) {
            // const departDateCollection = model.dDate.split('/');
            // const returnDateCollection = model.rDate ? model.rDate.split('/') : null;
            this.searchFormGroup.setValue({
                origin: orgPlace,
                destination: desPlace,
                departureDate: this.convertDate(new Date(model.dDate)),
                returnDate: model.rDate ?
                    this.convertDate(new Date(model.rDate)) : null,
                adultCount: model.adt == 0 ? 1 : model.adt,
                childCount: model.chld,
                infantCount: model.inf,
                marketingClass: [model.cabin],
                trip: model.rDate ? '0' : '1'
            });
        }
    }

}


export class MultiCityFlightSearchForm {
    private searchFormGroup!: FormGroup;

    /**
     *
     */
    constructor(private formBuilder: FormBuilder) {

    }


    public generateFormGroup(): FormGroup {
        this.searchFormGroup = this.formBuilder.group({
            name: ['', Validators.required],
            number: ['', Validators.required],
            email: ['', Validators.compose([Validators.required, Validators.email])],
            routes: this.formBuilder.array(this.generateRoutesForms()),
            adultCount: [1],
            childCount: [0],
            infantCount: [0],
            marketingClass: ['Y']
        });
        return this.searchFormGroup;
    }

    /**
     * generateRoutesForms
     */
    public generateRoutesForms(): FormGroup[] {
        const formGroup: FormGroup[] = [];
        formGroup.push(this.generateRouteFormGroup());
        return formGroup;
    }

    /**
     * generateRouteFormGroup
     */
    public generateRouteFormGroup() {
        return this.formBuilder.group({
            originIATA: ['', Validators.required],
            destinationIATA: ['', Validators.required],
            departDate: [this.convertDate(new Date(new Date().setDate(new Date().getDate() + 7))), Validators.required]
        });
    }

    private convertDate(date: Date): NgbDateStruct {
        return { day: date.getDate(), month: date.getMonth() + 1, year: date.getFullYear() };
    }

}
