import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path: 'result',
  loadChildren: () => import('./result/result.module').then(m => m.FlightResultModule)
}
  , {
    path: 'itinerary',
    loadChildren: () => import('./itinerary/itinerary.module').then(m => m.FlightItineraryModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightRoutingModule { }
