import { AfterViewInit, Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import 'moment-duration-format';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { FlightItineraryService } from './itinerary.service';
import { Router } from '@angular/router';
import { FlightsList } from '../../components/contracts';

@Component({
  selector: 'flight-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit, AfterViewInit {

  @Input() form!: FormGroup;
  @Input() result: FlightsList | undefined;

  @ViewChild('ccNumber') ccNumberField!: ElementRef;
  @ViewChild('ccExpiry') ccExpiryField!: ElementRef;
  @ViewChild('cardTypeField') cardTypeField!: ElementRef;

  tcFormControl = this.fb.control(false, Validators.requiredTrue);

  isProcessing = false;

  constructor(private fb: FormBuilder, private http: HttpClient,
    private flightItineraryService: FlightItineraryService, private route: Router, private el: ElementRef) { }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.cardTypeField) {
        this.cardTypeField.nativeElement.focus();
        this.cardTypeField.nativeElement.scrollIntoView({ behavior: "smooth" });
      }
    }, 500);
  }


  getDuration(durationInMinutes: string | number) {
    return (moment.duration(durationInMinutes, "minutes") as any).format("h[h] m[m]");
  }


  getTimeDiff(first: Date, second: Date) {
    const x = moment(second).diff(moment(first), 'minutes');
    return (moment.duration(x, "minutes") as any).format("h [Hrs.] m [Mins]");
  }


  getStopText(stop: number): string {
    if (stop == 1) {
      return 'NonStop';
    } else if (stop == 2) {
      return '1 Stop';
    } else {
      return stop - 1 + ' Stops';
    }
  }

  cvvChange() {
    const cardType = this.form.get('sagepayDetail.cardType')?.value;
    if (cardType == "amex") {
      this.form.get('sagepayDetail.cVV')?.setValidators(Validators.maxLength(4));
    } else {
      this.form.get('sagepayDetail.cVV')?.setValidators(Validators.maxLength(3));
    }
  }

  /* Insert spaces to enhance legibility of credit card numbers */
  creditCardNumberSpacing() {
    const input = this.ccNumberField.nativeElement;
    const { selectionStart } = input;
    const cardNumber = this.form.get('sagepayDetail.cardNumber');
    if (cardNumber) {

      let trimmedCardNum = cardNumber.value.replace(/-+/g, '');

      if (trimmedCardNum.length > 16) {
        trimmedCardNum = trimmedCardNum.substr(0, 16);
      }

      /* Handle American Express 4-6-5 spacing */
      const partitions = trimmedCardNum.startsWith('34') || trimmedCardNum.startsWith('37')
        ? [4, 6, 5]
        : [4, 4, 4, 4];

      const numbers: any[] = [];
      let position = 0;
      partitions.forEach(partition => {
        const part = trimmedCardNum.substr(position, partition);
        if (part) numbers.push(part);
        position += partition;
      })

      cardNumber.setValue(numbers.join('-'));

      /* Handle caret position if user edits the number later */
      if (selectionStart < cardNumber.value.length - 1) {
        input.setSelectionRange(selectionStart, selectionStart, 'none');
      }
    }
  }


  /* Insert spaces to enhance legibility of credit card numbers */
  creditCardExpirySpacing() {
    const input = this.ccExpiryField.nativeElement;
    const { selectionStart } = input;
    const cardExpiry = this.form.get('sagepayDetail.expiryDate');
    if (cardExpiry) {

      let trimmedCardExpiry = cardExpiry.value.replace(/\/+/g, '');

      if (trimmedCardExpiry.length > 16) {
        trimmedCardExpiry = trimmedCardExpiry.substr(0, 4);
      }

      /* Handle American Express 4-6-5 spacing */
      const partitions = [2, 2];

      const numbers: any[] = [];
      let position = 0;
      partitions.forEach(partition => {
        const part = trimmedCardExpiry.substr(position, partition);
        if (part) numbers.push(part);
        position += partition;
      })

      cardExpiry.setValue(numbers.join('\/'));

      /* Handle caret position if user edits the number later */
      if (selectionStart < cardExpiry.value.length - 1) {
        input.setSelectionRange(selectionStart, selectionStart, 'none');
      }
    }
  }

  makePayment() {
    if (this.isProcessing) {
      return;
    }
    if (this.form.valid && this.tcFormControl.valid) {
      this.isProcessing = true;
      this.http.post('/api/flights/itinerary/save', this.form.value)
        .subscribe({
          next: d => {
            this.flightItineraryService.flightItinerary = this.form.value;
            this.route.navigate(['/flights/itinerary/payment']);
          },
          complete: () => {
            this.isProcessing = false;
          },
          error: (err: HttpErrorResponse) => {
            this.isProcessing = false;
          }
        })
    } else {
      this.form.markAllAsTouched();
      this.tcFormControl.markAllAsTouched();
      setTimeout(() => {
        const invalidElement = this.el.nativeElement.querySelector('input.ng-invalid,select.ng-invalid');
        if (invalidElement) {
          invalidElement.focus();
          invalidElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 10);
    }
  }
}
