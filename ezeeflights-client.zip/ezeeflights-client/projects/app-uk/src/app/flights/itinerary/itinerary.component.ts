import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { AppHelper } from '../../components/app-helper';
import { FlightItineraryModel, FlightsList, PassengerType, Gender } from '../../components/contracts';
import { FlightCacheService } from '../../contracts/flights';

import { FlightItineraryService } from './itinerary.service';

@Component({
  selector: 'flight-itinerary',
  templateUrl: './itinerary.component.html',
  styleUrls: ['./itinerary.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ItineraryComponent implements OnInit {

  step = 0;
  form!: FormGroup;

  rawResultData: FlightItineraryModel | undefined;
  flight: FlightsList | undefined;
  hasLoaded = false;

  fromAirport: any;
  toAirport: any;

  flightClass: string | null = null;
  adult = 0;
  child = 0;
  infant = 0;
  flightWay = '';
  departDate = '';
  returnDate: string | null = null;
  searchId = '';
  tranId = '';

  constructor(private httpClient: HttpClient, route: ActivatedRoute, private router: Router, private fb: FormBuilder,
    private flightItineraryService: FlightItineraryService, private flightCacheService: FlightCacheService) {
    route.data.subscribe((d: any) => {
      this.fromAirport = d.airports[0];
      this.toAirport = d.airports[1];
    })
    route.queryParamMap.subscribe(q => {
      this.cleanBeforeSearch();
      const classData = AppHelper.extractQueryParamValueByKey('flightClass', q);
      if (classData) {
        switch (classData) {
          case '1':
            this.flightClass = 'First Class';
            break;
          case '2':
            this.flightClass = 'Business Class';
            break;
          case '3':
            this.flightClass = 'Premimum Economy Class';
            break;
          case '4':
            this.flightClass = 'Economy Class';
            break;
        }
      }
      this.adult = Number(AppHelper.extractQueryParamValueByKey('adt', q));
      this.child = Number(AppHelper.extractQueryParamValueByKey('chld', q));
      this.infant = Number(AppHelper.extractQueryParamValueByKey('inf', q));
      this.departDate = String(AppHelper.extractQueryParamValueByKey('dDate', q));
      this.returnDate = AppHelper.extractQueryParamKey('rDate', q) ? AppHelper.extractQueryParamValueByKey('rDate', q) : null;
      this.searchId = String(AppHelper.extractQueryParamValueByKey('searchId', q));
      this.tranId = String(AppHelper.extractQueryParamValueByKey('tranId', q));
      this.flightWay = this.returnDate ? 'Return' : 'Oneway';
      this.getItinerary((q as any).params);
    });
  }

  ngOnInit(): void {
  }

  private getItinerary(params: any) {
    this.httpClient.get<FlightItineraryModel>('/api/flights/itinerary', { params: params }).subscribe({
      next: (resultData) => {
        this.rawResultData = resultData;
        this.flightItineraryService.rawResultData = resultData;
        if (this.rawResultData && this.rawResultData.flights) {
          this.flight = this.rawResultData.flights;
          this.hasLoaded = true;
          this.generateForm();
        }
      },
      error: () => {
        this.hasLoaded = true;
      }
    });
  }

  moveStep(step: number) {
    this.step = step;
  }


  cleanBeforeSearch() {
    this.hasLoaded = false;
    this.rawResultData = undefined;
    this.flight = undefined;
  }

  //Forms building
  generateForm() {
    this.form = this.fb.group({
      bookingId: this.fb.control(''),
      flightsSearch: this.fb.control(this.rawResultData?.flightsSearch),
      searchId: this.fb.control(this.searchId),
      transcationId: this.fb.control(this.tranId),
      passengerDetail: this.generatePassengers(),
      phoneNo: this.fb.control('', Validators.required),
      email: this.fb.control('', [Validators.required, Validators.email]),
      bookerDetail: this.fb.group({
        address1: this.fb.control(''),
        address2: this.fb.control(''),
        city: this.fb.control(''),
        state: this.fb.control(''),
        country: this.fb.control('US', Validators.required),
        postCode: this.fb.control('')
      }),
      sagepayDetail: this.fb.group({
        cardType: this.fb.control('', Validators.required),
        cardHolderName: this.fb.control('', Validators.required),
        cardNumber: this.fb.control('', Validators.required),
        cVV: this.fb.control('', [Validators.required, Validators.maxLength(3)]),
        expiryMonth: this.fb.control('', Validators.required),
        expiryYear: this.fb.control('', Validators.required),
        expiryDate: this.fb.control('', [Validators.required, this.creditCardExpiryValidator()])
      })
    });

    this.form.get('sagepayDetail.expiryDate')?.valueChanges.subscribe((v: string) => {
      const data = v.split('/');
      if (data.length == 2) {
        this.form.get('sagepayDetail.expiryMonth')?.setValue(data[0]);
        this.form.get('sagepayDetail.expiryYear')?.setValue(data[1]);

      }
    })

  }

  private generatePassengers(): FormArray {
    let travellerNo = 0;
    const passengers = this.fb.array([]);
    if (this.adult) {
      this.generatePassenger(PassengerType.Adult, travellerNo, this.adult, passengers);
    }
    if (this.child) {
      this.generatePassenger(PassengerType.Child, travellerNo, this.child, passengers);
    }
    if (this.infant) {
      this.generatePassenger(PassengerType.Infant, travellerNo, this.infant, passengers);
    }
    return passengers;
  }

  generatePassenger(passengerType: PassengerType, travellerNo: number, paxQuantity: number, passengers: FormArray) {
    for (let index = 0; index < paxQuantity; index++) {
      travellerNo += 1;
      const passenger = this.fb.group({
        travelerNo: this.fb.control(travellerNo),
        passengerType: this.fb.control(passengerType),
        //title: this.fb.control('Mr', Validators.required),
        firstName: this.fb.control('', Validators.required),
        middleName: this.fb.control(''),
        lastName: this.fb.control('', Validators.required),
        dob: this.fb.control(''),
        dobday: this.fb.control('', Validators.required),
        dobmonth: this.fb.control('', Validators.required),
        dobyear: this.fb.control('', Validators.required),
        gender: this.fb.control(1, Validators.required),
        nationality: this.fb.control('US', Validators.required),
        passportNumber: this.fb.control(''),
        issueCountry: this.fb.control(''),
        //expiryDate: this.fb.control()
      });
      this.setDOBValue(passenger, 'dobday');
      this.setDOBValue(passenger, 'dobmonth');
      this.setDOBValue(passenger, 'dobyear');
      passengers.push(passenger);
    }
  }

  setDOBValue(passenger: FormGroup, controlName: string) {
    passenger.get(controlName)?.valueChanges.subscribe(v => {
      setTimeout(() => {
        const dobyear = passenger.get('dobyear')?.value;
        const dobmonth = passenger.get('dobmonth')?.value;
        const dobday = passenger.get('dobday')?.value;
        if (dobyear && dobmonth && dobday) {
          passenger.get('dob')?.setValue(moment(`${dobyear} ${dobmonth} ${dobday}`, 'YYYY MM DD').format('YYYY-MM-DD'));
        }
      }, 10);
    })
  }

  /** A hero's name can't match the given regular expression */
  creditCardExpiryValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (control.value.match(/^(0\d|1[0-2])\/\d{2}$/)) {
        const { 0: month, 1: year } = control.value.split("/");

        // get midnight of first day of the next month
        const expiry = new Date(+`20${year}`, month);
        const current = new Date();

        return expiry.getTime() > current.getTime() ? null : { expiryDate: { value: control.value } };

      } else return { expiryDate: { value: control.value } };
    };
  }

  getAirlineName(code: string) {
    return this.flightCacheService.airLineLookup(code);
  }


  getAirportName(code: string) {
    return this.flightCacheService.airportLookup(code);
  }


  getDuration(durationInMinutes: string | number) {
    return (moment.duration(durationInMinutes, "minutes") as any).format("h[h] m[m]");
  }


  getTimeDiff(first: Date, second: Date) {
    const x = moment(second).diff(moment(first), 'minutes');
    return (moment.duration(x, "minutes") as any).format("h [Hrs.] m [Mins]");
  }


  getStopText(stop: number): string {
    if (stop == 1) {
      return 'Nonstop';
    } else if (stop == 2) {
      return '1 Stop';
    } else {
      return stop - 1 + ' Stops';
    }
  }


  getClassText(classData: number) {
    let flightClass = '';
    switch (classData) {
      case 1:
        flightClass = 'First Class';
        break;
      case 2:
        flightClass = 'Business Class';
        break;
      case 3:
        flightClass = 'Premimum Economy Class';
        break;
      case 4:
        flightClass = 'Economy Class';
        break;
    }
    return flightClass;
  }

  getPassengerDetailsFormArray(): FormArray {
    return this.form.get('passengerDetail') as FormArray;
  }

}
