import { Injectable } from '@angular/core';
import { FlightItineraryModel } from '../../components/contracts';

@Injectable()
export class FlightItineraryService {
  rawResultData!: FlightItineraryModel;
  flightItinerary!: FlightItineraryModel;
  paymentStatus!: string;
}
