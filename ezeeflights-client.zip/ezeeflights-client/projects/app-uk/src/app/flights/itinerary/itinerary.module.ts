import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItineraryComponent } from './itinerary.component';
import { PassengerComponent } from './passenger.component';
import { FlightItineraryRoutingModule } from './itinerary-routing.module';
import { BookingComponent } from './booking.component';
import { FlightItineraryService } from './itinerary.service';
import { ReactiveFormsModule } from '@angular/forms';
import { PaymentComponent } from './payment/payment.component';
import { FlightLoadingModule } from '../../components/loading/flight-loading.module';
import { FlightNotFoundModule } from '../../components/not-found/flight-loading.module';
import { FlightResultResolver } from '../../components/result-resolver';
import { StopIndModule } from '../../components/stop-ind/stop-ind.module';


@NgModule({
  declarations: [
    ItineraryComponent,
    PassengerComponent,
    BookingComponent,
    PaymentComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FlightLoadingModule,
    FlightNotFoundModule,
    StopIndModule,
    FlightItineraryRoutingModule
  ],
  providers: [FlightItineraryService, FlightResultResolver]
})
export class FlightItineraryModule { }
